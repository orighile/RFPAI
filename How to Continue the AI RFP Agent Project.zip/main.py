import sys
import os
import logging # Added missing import
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, request, render_template, redirect, url_for, send_from_directory, flash
import subprocess
import uuid
import shutil

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Define the base directory of the Flask app
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Configuration for file uploads and generated files
# UPLOAD_FOLDER is inside the Flask app's static directory for simplicity in this example
# In a production app, this might be outside the app directory or use a more robust storage solution.
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads_temp')
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Path to the AI RFP Agent and its output directory
# IMPORTANT: This assumes the ai_rfp_agent project is in /home/ubuntu/ai_rfp_agent/home/ubuntu/ai_rfp_agent
AI_AGENT_PROJECT_DIR = "/home/ubuntu/ai_rfp_agent/home/ubuntu/ai_rfp_agent"
RUN_AGENT_SCRIPT = os.path.join(AI_AGENT_PROJECT_DIR, "run_proposal_agent.py")
GENERATED_PROPOSALS_DIR = os.path.join(AI_AGENT_PROJECT_DIR, "generated_proposals")

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['GENERATED_PROPOSALS_DIR'] = GENERATED_PROPOSALS_DIR

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'rfp_file' not in request.files:
        flash('No file part', 'error')
        return redirect(url_for('index'))
    
    file = request.files['rfp_file']
    proposal_title = request.form.get('proposal_title', 'Untitled Proposal')

    if file.filename == '':
        flash('No selected file', 'error')
        return redirect(url_for('index'))

    if file and (file.filename.endswith('.pdf') or file.filename.endswith('.txt')):
        # Save the uploaded file temporarily
        original_filename = file.filename
        temp_filename = str(uuid.uuid4()) + os.path.splitext(original_filename)[1]
        temp_filepath = os.path.join(app.config['UPLOAD_FOLDER'], temp_filename)
        file.save(temp_filepath)
        
        input_filepath_for_agent = temp_filepath

        try:
            if not os.path.exists(app.config['GENERATED_PROPOSALS_DIR']):
                 os.makedirs(app.config['GENERATED_PROPOSALS_DIR'])

            cmd = [
                "python3", 
                RUN_AGENT_SCRIPT, 
                input_filepath_for_agent, 
                proposal_title
            ]
            logging.info(f"Running command: {' '.join(cmd)} in CWD: {AI_AGENT_PROJECT_DIR}")
            
            process = subprocess.Popen(cmd, cwd=AI_AGENT_PROJECT_DIR, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            stdout, stderr = process.communicate()

            logging.info(f"Agent STDOUT: {stdout}")
            logging.error(f"Agent STDERR: {stderr}")

            if process.returncode != 0:
                flash(f'Error running AI agent: {stderr}', 'error')
                return render_template('index.html', message=f'Error running AI agent: {stderr}', message_type='error')

            generated_files_map = {}
            if "Generated proposal documents:" in stdout:
                lines = stdout.splitlines()
                parsing_files = False
                for line in lines:
                    if "Generated proposal documents:" in line:
                        parsing_files = True
                        continue
                    if parsing_files and line.strip().startswith("markdown_proposal:"):
                        generated_files_map["markdown_proposal"] = line.split(":",1)[1].strip()
                    elif parsing_files and line.strip().startswith("costing_csv:"):
                        generated_files_map["costing_csv"] = line.split(":",1)[1].strip()
                    elif parsing_files and line.strip().startswith("review_csv:"):
                        generated_files_map["review_csv"] = line.split(":",1)[1].strip()
            
            if not generated_files_map:
                flash('AI agent ran but did not produce expected output file paths.', 'error')
                return render_template('index.html', message='AI agent ran but did not produce expected output file paths.', message_type='error')

            display_files = {}
            for key, abs_path in generated_files_map.items():
                if os.path.exists(abs_path) and abs_path.startswith(app.config['GENERATED_PROPOSALS_DIR']):
                    display_files[key] = os.path.basename(abs_path)
                else:
                    logging.error(f"Generated file {abs_path} for {key} not found or not in expected directory.")
            
            if not display_files:
                flash('Could not find generated files for download.', 'error')
                return render_template('index.html', message='Could not find generated files for download.', message_type='error')

            flash('Proposal generated successfully!', 'success')
            return render_template('index.html', message='Proposal generated successfully!', message_type='success', proposal_files=display_files)

        except subprocess.CalledProcessError as e:
            flash(f'Error during proposal generation: {e.stderr}', 'error')
            return render_template('index.html', message=f'Error during proposal generation: {e.stderr}', message_type='error')
        except Exception as e:
            flash(f'An unexpected error occurred: {str(e)}', 'error')
            logging.error(f"Unexpected error: {str(e)}", exc_info=True)
            return render_template('index.html', message=f'An unexpected error occurred: {str(e)}', message_type='error')
        finally:
            if os.path.exists(temp_filepath):
                os.remove(temp_filepath)
    else:
        flash('Invalid file type. Please upload a PDF or TXT file.', 'error')
        return redirect(url_for('index'))

@app.route('/download/<filename>')
def download_file(filename):
    try:
        return send_from_directory(app.config['GENERATED_PROPOSALS_DIR'], filename, as_attachment=True)
    except FileNotFoundError:
        flash('File not found.', 'error')
        return redirect(url_for('index'))

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
    app.run(host='0.0.0.0', port=5001, debug=True)

