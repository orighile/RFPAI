import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import KnowledgeBaseManager from '../components/knowledge/KnowledgeBaseManager';
import { KnowledgeBaseProvider } from '../contexts/KnowledgeBaseContext';

// Mock the API service
jest.mock('../services/ApiService', () => ({
  knowledgeBase: {
    search: jest.fn(),
    create: jest.fn(),
    getCategories: jest.fn().mockResolvedValue({
      data: [
        { id: 'all', name: 'All Items' },
        { id: 'rfp_insights', name: 'RFP Insights' },
        { id: 'proposal_feedback', name: 'Proposal Feedback' },
        { id: 'best_practices', name: 'Best Practices' },
        { id: 'lessons_learned', name: 'Lessons Learned' }
      ]
    })
  },
}));

describe('KnowledgeBaseManager Component', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
  });

  test('renders knowledge base manager correctly', () => {
    render(
      <KnowledgeBaseProvider>
        <KnowledgeBaseManager />
      </KnowledgeBaseProvider>
    );
    
    // Check if important elements are rendered
    expect(screen.getByText('Knowledge Base Manager')).toBeInTheDocument();
    expect(screen.getByText('Add New Entry')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Search knowledge base...')).toBeInTheDocument();
    expect(screen.getByText('All Items')).toBeInTheDocument();
  });

  test('handles search functionality', async () => {
    const mockSearch = jest.fn().mockResolvedValue({ data: [] });
    require('../services/ApiService').knowledgeBase.search = mockSearch;
    
    render(
      <KnowledgeBaseProvider>
        <KnowledgeBaseManager />
      </KnowledgeBaseProvider>
    );
    
    const searchInput = screen.getByPlaceholderText('Search knowledge base...');
    const searchButton = screen.getByRole('button', { name: /Search/i });
    
    fireEvent.change(searchInput, { target: { value: 'technical approach' } });
    fireEvent.click(searchButton);
    
    await waitFor(() => {
      expect(mockSearch).toHaveBeenCalled();
    });
  });

  test('toggles add new entry form', () => {
    render(
      <KnowledgeBaseProvider>
        <KnowledgeBaseManager />
      </KnowledgeBaseProvider>
    );
    
    const addButton = screen.getByText('Add New Entry');
    
    // Form should not be visible initially
    expect(screen.queryByText('Add New Knowledge Entry')).not.toBeInTheDocument();
    
    // Click to show form
    fireEvent.click(addButton);
    
    // Form should now be visible
    expect(screen.getByText('Add New Knowledge Entry')).toBeInTheDocument();
    
    // Click cancel to hide form
    const cancelButton = screen.getByRole('button', { name: /Cancel/i });
    fireEvent.click(cancelButton);
    
    // Form should be hidden again
    expect(screen.queryByText('Add New Knowledge Entry')).not.toBeInTheDocument();
  });

  test('handles adding new knowledge entry', async () => {
    const mockCreate = jest.fn().mockResolvedValue({ 
      data: { 
        id: '123', 
        title: 'Test Entry', 
        description: 'Test Description',
        category: 'best_practices',
        keywords: ['test', 'entry'],
        source: 'Test Source'
      } 
    });
    require('../services/ApiService').knowledgeBase.create = mockCreate;
    
    render(
      <KnowledgeBaseProvider>
        <KnowledgeBaseManager />
      </KnowledgeBaseProvider>
    );
    
    // Open the form
    const addButton = screen.getByText('Add New Entry');
    fireEvent.click(addButton);
    
    // Fill out the form
    const titleInput = screen.getByLabelText(/Title/i);
    const descriptionInput = screen.getByLabelText(/Description/i);
    const categorySelect = screen.getByLabelText(/Category/i);
    const sourceInput = screen.getByLabelText(/Source/i);
    const keywordsInput = screen.getByLabelText(/Keywords/i);
    
    fireEvent.change(titleInput, { target: { value: 'Test Entry' } });
    fireEvent.change(descriptionInput, { target: { value: 'Test Description' } });
    fireEvent.change(categorySelect, { target: { value: 'best_practices' } });
    fireEvent.change(sourceInput, { target: { value: 'Test Source' } });
    fireEvent.change(keywordsInput, { target: { value: 'test, entry' } });
    
    // Submit the form
    const submitButton = screen.getByRole('button', { name: /Add Entry/i });
    fireEvent.click(submitButton);
    
    await waitFor(() => {
      expect(mockCreate).toHaveBeenCalled();
    });
  });
});
