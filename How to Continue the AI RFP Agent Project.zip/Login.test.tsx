import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import Login from '../components/auth/Login';
import { AuthProvider } from '../contexts/AuthContext';

// Mock the API service
jest.mock('../services/ApiService', () => ({
  auth: {
    login: jest.fn(),
  },
}));

describe('Login Component', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
  });

  test('renders login form correctly', () => {
    render(
      <AuthProvider>
        <Login />
      </AuthProvider>
    );
    
    // Check if important elements are rendered
    expect(screen.getByText('AI RFP Agent')).toBeInTheDocument();
    expect(screen.getByText('Sign in to access your account')).toBeInTheDocument();
    expect(screen.getByLabelText(/Email address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Sign in/i })).toBeInTheDocument();
    expect(screen.getByText('Forgot your password?')).toBeInTheDocument();
  });

  test('handles input changes', () => {
    render(
      <AuthProvider>
        <Login />
      </AuthProvider>
    );
    
    const emailInput = screen.getByLabelText(/Email address/i);
    const passwordInput = screen.getByLabelText(/Password/i);
    
    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    
    expect(emailInput.value).toBe('test@example.com');
    expect(passwordInput.value).toBe('password123');
  });

  test('handles form submission', async () => {
    const mockLogin = jest.fn().mockResolvedValue({});
    require('../services/ApiService').auth.login = mockLogin;
    
    render(
      <AuthProvider>
        <Login />
      </AuthProvider>
    );
    
    const emailInput = screen.getByLabelText(/Email address/i);
    const passwordInput = screen.getByLabelText(/Password/i);
    const submitButton = screen.getByRole('button', { name: /Sign in/i });
    
    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    fireEvent.click(submitButton);
    
    await waitFor(() => {
      expect(mockLogin).toHaveBeenCalledWith({
        email: 'test@example.com',
        password: 'password123',
      });
    });
  });

  test('handles remember me checkbox', () => {
    render(
      <AuthProvider>
        <Login />
      </AuthProvider>
    );
    
    const rememberMeCheckbox = screen.getByLabelText(/Remember me/i);
    
    expect(rememberMeCheckbox).not.toBeChecked();
    
    fireEvent.click(rememberMeCheckbox);
    
    expect(rememberMeCheckbox).toBeChecked();
  });
});
