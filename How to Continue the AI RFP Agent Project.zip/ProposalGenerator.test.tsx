import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import ProposalGenerator from '../components/proposals/ProposalGenerator';
import { RfpProvider } from '../contexts/RfpContext';
import { ProposalProvider } from '../contexts/ProposalContext';

// Mock the API service
jest.mock('../services/ApiService', () => ({
  rfp: {
    getAll: jest.fn().mockResolvedValue({
      data: [
        { id: 'rfp1', title: 'Sample RFP 1', status: 'analyzed' },
        { id: 'rfp2', title: 'Sample RFP 2', status: 'uploaded' }
      ]
    })
  },
  proposal: {
    generate: jest.fn()
  }
}));

describe('ProposalGenerator Component', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
  });

  test('renders proposal generator form correctly', () => {
    render(
      <RfpProvider>
        <ProposalProvider>
          <ProposalGenerator />
        </ProposalProvider>
      </RfpProvider>
    );
    
    // Check if important elements are rendered
    expect(screen.getByText(/Generate New Proposal/i)).toBeInTheDocument();
    expect(screen.getByText(/Select RFP Document/i)).toBeInTheDocument();
    expect(screen.getByText(/Proposal Settings/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Generate Proposal/i })).toBeInTheDocument();
  });

  test('handles RFP selection', async () => {
    render(
      <RfpProvider>
        <ProposalProvider>
          <ProposalGenerator />
        </ProposalProvider>
      </RfpProvider>
    );
    
    // Wait for RFPs to load
    await waitFor(() => {
      expect(screen.getByText('Sample RFP 1')).toBeInTheDocument();
    });
    
    // Select an RFP
    const rfpSelect = screen.getByLabelText(/Select RFP/i);
    fireEvent.change(rfpSelect, { target: { value: 'rfp1' } });
    
    expect(rfpSelect.value).toBe('rfp1');
  });

  test('handles form submission', async () => {
    const mockGenerate = jest.fn().mockResolvedValue({ 
      data: { 
        id: 'prop1', 
        title: 'Generated Proposal', 
        status: 'in_progress' 
      } 
    });
    require('../services/ApiService').proposal.generate = mockGenerate;
    
    render(
      <RfpProvider>
        <ProposalProvider>
          <ProposalGenerator />
        </ProposalProvider>
      </RfpProvider>
    );
    
    // Wait for RFPs to load
    await waitFor(() => {
      expect(screen.getByText('Sample RFP 1')).toBeInTheDocument();
    });
    
    // Fill out the form
    const rfpSelect = screen.getByLabelText(/Select RFP/i);
    const titleInput = screen.getByLabelText(/Proposal Title/i);
    
    fireEvent.change(rfpSelect, { target: { value: 'rfp1' } });
    fireEvent.change(titleInput, { target: { value: 'Test Proposal' } });
    
    // Submit the form
    const submitButton = screen.getByRole('button', { name: /Generate Proposal/i });
    fireEvent.click(submitButton);
    
    await waitFor(() => {
      expect(mockGenerate).toHaveBeenCalledWith({
        rfpId: 'rfp1',
        title: 'Test Proposal',
        settings: expect.any(Object)
      });
    });
  });

  test('displays error when no RFP is selected', async () => {
    render(
      <RfpProvider>
        <ProposalProvider>
          <ProposalGenerator />
        </ProposalProvider>
      </RfpProvider>
    );
    
    // Fill out the form partially (missing RFP selection)
    const titleInput = screen.getByLabelText(/Proposal Title/i);
    fireEvent.change(titleInput, { target: { value: 'Test Proposal' } });
    
    // Submit the form
    const submitButton = screen.getByRole('button', { name: /Generate Proposal/i });
    fireEvent.click(submitButton);
    
    await waitFor(() => {
      expect(screen.getByText(/Please select an RFP document/i)).toBeInTheDocument();
    });
  });
});
