import React, { createContext, useContext, useState, useEffect } from 'react';
import ApiService from '../services/ApiService';

// Define the Knowledge Base context type
interface KnowledgeBaseContextType {
  knowledgeItems: any[];
  categories: any[];
  isLoading: boolean;
  error: string | null;
  searchKnowledge: (params?: any) => Promise<void>;
  getKnowledgeItem: (id: string) => Promise<any>;
  createKnowledgeItem: (data: any) => Promise<any>;
  updateKnowledgeItem: (id: string, data: any) => Promise<any>;
  deleteKnowledgeItem: (id: string) => Promise<void>;
  fetchCategories: () => Promise<void>;
}

// Create the Knowledge Base context
const KnowledgeBaseContext = createContext<KnowledgeBaseContextType>({
  knowledgeItems: [],
  categories: [],
  isLoading: false,
  error: null,
  searchKnowledge: async () => {},
  getKnowledgeItem: async () => ({}),
  createKnowledgeItem: async () => ({}),
  updateKnowledgeItem: async () => ({}),
  deleteKnowledgeItem: async () => {},
  fetchCategories: async () => {},
});

// Knowledge Base provider component
export const KnowledgeBaseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [knowledgeItems, setKnowledgeItems] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch knowledge base categories
  const fetchCategories = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.knowledgeBase.getCategories();
      setCategories(response.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch categories');
      console.error('Error fetching categories:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Search knowledge base
  const searchKnowledge = async (params?: any) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.knowledgeBase.search(params);
      setKnowledgeItems(response.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to search knowledge base');
      console.error('Error searching knowledge base:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Get a specific knowledge item
  const getKnowledgeItem = async (id: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.knowledgeBase.getById(id);
      return response.data;
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch knowledge item');
      console.error('Error fetching knowledge item:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Create a new knowledge item
  const createKnowledgeItem = async (data: any) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.knowledgeBase.create(data);
      setKnowledgeItems((prevItems) => [...prevItems, response.data]);
      return response.data;
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to create knowledge item');
      console.error('Error creating knowledge item:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Update a knowledge item
  const updateKnowledgeItem = async (id: string, data: any) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.knowledgeBase.update(id, data);
      setKnowledgeItems((prevItems) =>
        prevItems.map((item) => (item.id === id ? response.data : item))
      );
      return response.data;
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to update knowledge item');
      console.error('Error updating knowledge item:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Delete a knowledge item
  const deleteKnowledgeItem = async (id: string) => {
    setIsLoading(true);
    setError(null);
    try {
      await ApiService.knowledgeBase.delete(id);
      setKnowledgeItems((prevItems) => prevItems.filter((item) => item.id !== id));
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to delete knowledge item');
      console.error('Error deleting knowledge item:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Load categories on initial mount
  useEffect(() => {
    fetchCategories();
  }, []);

  return (
    <KnowledgeBaseContext.Provider
      value={{
        knowledgeItems,
        categories,
        isLoading,
        error,
        searchKnowledge,
        getKnowledgeItem,
        createKnowledgeItem,
        updateKnowledgeItem,
        deleteKnowledgeItem,
        fetchCategories,
      }}
    >
      {children}
    </KnowledgeBaseContext.Provider>
  );
};

// Custom hook to use the Knowledge Base context
export const useKnowledgeBase = () => useContext(KnowledgeBaseContext);
