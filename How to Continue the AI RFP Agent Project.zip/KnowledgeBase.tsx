import React, { useState, useEffect } from 'react';
import ApiService from '../../services/ApiService';

const KnowledgeBase: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [knowledgeItems, setKnowledgeItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [totalItems, setTotalItems] = useState(0);
  const [categories, setCategories] = useState([
    { id: 'all', name: 'All Categories' },
    { id: 'technical', name: 'Technical' },
    { id: 'compliance', name: 'Compliance' },
    { id: 'pricing', name: 'Pricing' },
    { id: 'past_performance', name: 'Past Performance' }
  ]);

  useEffect(() => {
    fetchKnowledgeItems();
  }, [searchQuery, selectedCategory, currentPage, itemsPerPage]);

  const fetchKnowledgeItems = async () => {
    setLoading(true);
    setError('');
    
    try {
      const params = {
        query: searchQuery,
        category: selectedCategory !== 'all' ? selectedCategory : undefined,
        page: currentPage,
        limit: itemsPerPage
      };
      
      const response = await ApiService.knowledgeBase.search(params);
      
      if (response.data) {
        setKnowledgeItems(response.data.items || []);
        setTotalPages(response.data.totalPages || 1);
        setTotalItems(response.data.totalItems || 0);
      } else {
        // Fallback to sample data
        const sampleData = generateSampleData();
        setKnowledgeItems(sampleData.items);
        setTotalPages(sampleData.totalPages);
        setTotalItems(sampleData.totalItems);
      }
    } catch (error) {
      console.error('Error fetching knowledge items:', error);
      setError('Failed to load knowledge base items. Please try again.');
      
      // Fallback to sample data
      const sampleData = generateSampleData();
      setKnowledgeItems(sampleData.items);
      setTotalPages(sampleData.totalPages);
      setTotalItems(sampleData.totalItems);
    } finally {
      setLoading(false);
    }
  };

  const generateSampleData = () => {
    // Generate sample data based on current filters
    const allItems = [
      {
        id: 'kb-1',
        title: 'Federal Acquisition Regulation Compliance',
        category: 'compliance',
        content: 'Key points for ensuring FAR compliance in government proposals...',
        tags: ['FAR', 'compliance', 'government'],
        createdAt: '2025-01-15T10:30:00Z',
        updatedAt: '2025-03-20T14:45:00Z'
      },
      {
        id: 'kb-2',
        title: 'Cloud Infrastructure Cost Models',
        category: 'pricing',
        content: 'Breakdown of pricing models for cloud infrastructure services...',
        tags: ['cloud', 'pricing', 'infrastructure'],
        createdAt: '2025-02-10T09:15:00Z',
        updatedAt: '2025-04-05T11:20:00Z'
      },
      {
        id: 'kb-3',
        title: 'NIST Cybersecurity Framework Implementation',
        category: 'technical',
        content: 'Guidelines for implementing NIST cybersecurity framework...',
        tags: ['NIST', 'cybersecurity', 'compliance'],
        createdAt: '2025-01-25T13:45:00Z',
        updatedAt: '2025-03-15T16:30:00Z'
      },
      {
        id: 'kb-4',
        title: 'Department of Defense Project References',
        category: 'past_performance',
        content: 'Case studies and references for DoD projects...',
        tags: ['DoD', 'references', 'past performance'],
        createdAt: '2025-03-05T11:00:00Z',
        updatedAt: '2025-04-10T09:45:00Z'
      },
      {
        id: 'kb-5',
        title: 'Agile Development Methodologies',
        category: 'technical',
        content: 'Overview of agile methodologies for government projects...',
        tags: ['agile', 'development', 'methodology'],
        createdAt: '2025-02-20T14:30:00Z',
        updatedAt: '2025-04-15T10:15:00Z'
      },
      {
        id: 'kb-6',
        title: 'Section 508 Compliance Requirements',
        category: 'compliance',
        content: 'Detailed requirements for Section 508 compliance...',
        tags: ['accessibility', 'Section 508', 'compliance'],
        createdAt: '2025-01-30T09:30:00Z',
        updatedAt: '2025-03-25T13:45:00Z'
      },
      {
        id: 'kb-7',
        title: 'Fixed Price vs. Time & Materials Contracts',
        category: 'pricing',
        content: 'Comparison of different contract pricing models...',
        tags: ['contracts', 'pricing', 'models'],
        createdAt: '2025-02-05T15:20:00Z',
        updatedAt: '2025-04-01T11:30:00Z'
      },
      {
        id: 'kb-8',
        title: 'Healthcare IT System Implementation Case Study',
        category: 'past_performance',
        content: 'Case study of successful healthcare IT system implementation...',
        tags: ['healthcare', 'IT', 'case study'],
        createdAt: '2025-03-10T10:45:00Z',
        updatedAt: '2025-04-20T14:15:00Z'
      },
      {
        id: 'kb-9',
        title: 'DevSecOps Pipeline Implementation',
        category: 'technical',
        content: 'Best practices for implementing DevSecOps pipelines...',
        tags: ['DevSecOps', 'CI/CD', 'security'],
        createdAt: '2025-02-25T13:15:00Z',
        updatedAt: '2025-04-12T09:30:00Z'
      },
      {
        id: 'kb-10',
        title: 'CMMC 2.0 Compliance Framework',
        category: 'compliance',
        content: 'Overview of CMMC 2.0 compliance requirements...',
        tags: ['CMMC', 'cybersecurity', 'compliance'],
        createdAt: '2025-01-20T11:45:00Z',
        updatedAt: '2025-03-30T15:20:00Z'
      },
      {
        id: 'kb-11',
        title: 'Cloud Migration Cost Analysis',
        category: 'pricing',
        content: 'Framework for analyzing costs associated with cloud migration...',
        tags: ['cloud', 'migration', 'cost analysis'],
        createdAt: '2025-02-15T10:30:00Z',
        updatedAt: '2025-04-08T13:45:00Z'
      },
      {
        id: 'kb-12',
        title: 'Federal Agency Data Center Consolidation',
        category: 'past_performance',
        content: 'Case study of federal agency data center consolidation project...',
        tags: ['data center', 'consolidation', 'federal'],
        createdAt: '2025-03-15T14:15:00Z',
        updatedAt: '2025-04-25T11:30:00Z'
      },
      {
        id: 'kb-13',
        title: 'Zero Trust Architecture Implementation',
        category: 'technical',
        content: 'Guidelines for implementing zero trust architecture...',
        tags: ['zero trust', 'security', 'architecture'],
        createdAt: '2025-02-28T09:45:00Z',
        updatedAt: '2025-04-18T15:15:00Z'
      },
      {
        id: 'kb-14',
        title: 'FedRAMP Compliance Checklist',
        category: 'compliance',
        content: 'Comprehensive checklist for FedRAMP compliance...',
        tags: ['FedRAMP', 'cloud', 'compliance'],
        createdAt: '2025-01-10T13:30:00Z',
        updatedAt: '2025-03-05T10:45:00Z'
      },
      {
        id: 'kb-15',
        title: 'Software Development Labor Categories and Rates',
        category: 'pricing',
        content: 'Standard labor categories and rate ranges for software development...',
        tags: ['labor', 'rates', 'software development'],
        createdAt: '2025-02-01T11:15:00Z',
        updatedAt: '2025-04-03T14:30:00Z'
      }
    ];
    
    // Filter by category if needed
    let filteredItems = allItems;
    if (selectedCategory !== 'all') {
      filteredItems = allItems.filter(item => item.category === selectedCategory);
    }
    
    // Filter by search query if provided
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filteredItems = filteredItems.filter(item => 
        item.title.toLowerCase().includes(query) || 
        item.content.toLowerCase().includes(query) || 
        item.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }
    
    // Calculate pagination
    const totalFilteredItems = filteredItems.length;
    const totalFilteredPages = Math.ceil(totalFilteredItems / itemsPerPage);
    
    // Get items for current page
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const itemsForCurrentPage = filteredItems.slice(startIndex, endIndex);
    
    return {
      items: itemsForCurrentPage,
      totalItems: totalFilteredItems,
      totalPages: totalFilteredPages
    };
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    setCurrentPage(1); // Reset to first page on new search
  };

  const handleCategoryChange = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setCurrentPage(1); // Reset to first page on category change
  };

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const handleItemsPerPageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setItemsPerPage(Number(e.target.value));
    setCurrentPage(1); // Reset to first page when changing items per page
  };

  const handleCreateNewEntry = () => {
    window.location.href = '/knowledge/new';
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Knowledge Base</h1>
        <button
          onClick={handleCreateNewEntry}
          className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark flex items-center"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          New Entry
        </button>
      </div>
      
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 rounded-md p-4">
          {error}
        </div>
      )}
      
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0 md:space-x-4">
          <div className="flex-1">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={handleSearchChange}
                placeholder="Search knowledge base..."
                className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => handleCategoryChange(category.id)}
                className={`px-3 py-1 text-sm rounded-full ${
                  selectedCategory === category.id
                    ? 'bg-primary text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-medium text-gray-900">
            {totalItems} {totalItems === 1 ? 'Result' : 'Results'}
            {selectedCategory !== 'all' && ` in ${categories.find(c => c.id === selectedCategory)?.name}`}
            {searchQuery && ` for "${searchQuery}"`}
          </h2>
          
          <div className="flex items-center">
            <label htmlFor="itemsPerPage" className="mr-2 text-sm text-gray-700">
              Show:
            </label>
            <select
              id="itemsPerPage"
              value={itemsPerPage}
              onChange={handleItemsPerPageChange}
              className="border border-gray-300 rounded-md text-sm p-1"
            >
              <option value="5">5</option>
              <option value="10">10</option>
              <option value="20">20</option>
              <option value="50">50</option>
            </select>
          </div>
        </div>
        
        {loading ? (
          <div className="p-6 text-center">
            <p className="text-gray-500">Loading knowledge base entries...</p>
          </div>
        ) : knowledgeItems.length === 0 ? (
          <div className="p-6 text-center">
            <p className="text-gray-500">No knowledge base entries found.</p>
          </div>
        ) : (
          <>
            <ul className="divide-y divide-gray-200">
              {knowledgeItems.map((item: any) => (
                <li key={item.id} className="p-6">
                  <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                    <div className="flex-1">
                      <h3 className="text-lg font-medium text-gray-900 hover:text-primary">
                        <a href={`/knowledge/${item.id}`}>{item.title}</a>
                      </h3>
                      
                      <p className="mt-1 text-sm text-gray-500">
                        Category: {item.category.charAt(0).toUpperCase() + item.category.slice(1)}
                      </p>
                      
                      <p className="mt-2 text-gray-700">{item.content}</p>
                      
                      <div className="mt-2 flex flex-wrap gap-1">
                        {item.tags.map((tag: string) => (
                          <span key={tag} className="px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded-full">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="mt-2 md:mt-0 md:ml-6 text-right flex-shrink-0">
                      <p className="text-sm text-gray-500">
                        Updated: {formatDate(item.updatedAt)}
                      </p>
                      <div className="mt-2 flex justify-end space-x-2">
                        <a
                          href={`/knowledge/${item.id}`}
                          className="text-primary hover:text-primary-dark text-sm"
                        >
                          View
                        </a>
                        <a
                          href={`/knowledge/${item.id}/edit`}
                          className="text-gray-500 hover:text-gray-700 text-sm"
                        >
                          Edit
                        </a>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            
            {totalPages > 1 && (
              <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
                <div className="flex-1 flex justify-between sm:
(Content truncated due to size limit. Use line ranges to read in chunks)