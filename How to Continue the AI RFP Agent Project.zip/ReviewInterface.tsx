import React, { useState, useEffect } from 'react';
import ApiService from '../../services/ApiService';

const ReviewInterface: React.FC = () => {
  const [proposals, setProposals] = useState([]);
  const [selectedProposal, setSelectedProposal] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    fetchProposals();
  }, []);

  const fetchProposals = async () => {
    setLoading(true);
    setError('');
    
    try {
      const response = await ApiService.proposal.getAll({ status: 'review' });
      
      if (response.data?.proposals) {
        setProposals(response.data.proposals);
      } else {
        // Fallback to sample data
        setProposals([
          {
            id: 'prop-1',
            title: 'Weather System Proposal for Sky Analytics',
            client: 'Sky Analytics Inc.',
            status: 'In Review',
            dueDate: '2025-05-20T00:00:00Z',
            createdAt: '2025-05-01T10:30:00Z',
            reviewCount: 2
          },
          {
            id: 'prop-2',
            title: 'Federal Healthcare RFP Response',
            client: 'HHS',
            status: 'In Review',
            dueDate: '2025-06-15T00:00:00Z',
            createdAt: '2025-05-05T14:45:00Z',
            reviewCount: 0
          },
          {
            id: 'prop-3',
            title: 'Cloud Migration Proposal',
            client: 'State Department',
            status: 'In Review',
            dueDate: '2025-05-30T00:00:00Z',
            createdAt: '2025-04-28T09:15:00Z',
            reviewCount: 5
          }
        ]);
      }
    } catch (error) {
      console.error('Error fetching proposals:', error);
      setError('Failed to load proposals for review. Please try again.');
      
      // Fallback to sample data
      setProposals([
        {
          id: 'prop-1',
          title: 'Weather System Proposal for Sky Analytics',
          client: 'Sky Analytics Inc.',
          status: 'In Review',
          dueDate: '2025-05-20T00:00:00Z',
          createdAt: '2025-05-01T10:30:00Z',
          reviewCount: 2
        },
        {
          id: 'prop-2',
          title: 'Federal Healthcare RFP Response',
          client: 'HHS',
          status: 'In Review',
          dueDate: '2025-06-15T00:00:00Z',
          createdAt: '2025-05-05T14:45:00Z',
          reviewCount: 0
        },
        {
          id: 'prop-3',
          title: 'Cloud Migration Proposal',
          client: 'State Department',
          status: 'In Review',
          dueDate: '2025-05-30T00:00:00Z',
          createdAt: '2025-04-28T09:15:00Z',
          reviewCount: 5
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const fetchProposalDetails = async (proposalId) => {
    setLoading(true);
    setError('');
    setSelectedProposal(null);
    
    try {
      const response = await ApiService.proposal.getById(proposalId);
      
      if (response.data) {
        setSelectedProposal(response.data);
      } else {
        // Fallback to sample data
        setSelectedProposal({
          id: proposalId,
          title: proposals.find(p => p.id === proposalId)?.title || 'Proposal Details',
          client: proposals.find(p => p.id === proposalId)?.client || 'Client Name',
          status: 'In Review',
          dueDate: proposals.find(p => p.id === proposalId)?.dueDate || '2025-05-30T00:00:00Z',
          createdAt: proposals.find(p => p.id === proposalId)?.createdAt || '2025-05-01T10:30:00Z',
          sections: [
            {
              title: 'Executive Summary',
              content: 'This proposal outlines our approach to developing a cloud-based weather analytics system for Sky Analytics Inc. Our solution leverages advanced AI and real-time data processing to provide accurate forecasting with minimal latency.'
            },
            {
              title: 'Technical Approach',
              content: 'Our technical approach combines state-of-the-art machine learning models with scalable cloud infrastructure. We will implement a distributed processing system capable of handling extreme weather events with sub-second response times.'
            },
            {
              title: 'Past Performance',
              content: 'We have successfully delivered similar systems for three federal agencies, all of which have reported 99.9% uptime and 95% forecast accuracy improvements.'
            },
            {
              title: 'Cost Breakdown',
              content: 'The total project cost of $250,000 includes $150,000 for development, $50,000 for testing and deployment, and $50,000 for first-year maintenance and support.'
            }
          ],
          reviews: [
            {
              id: 'rev-1',
              reviewer: 'John Smith',
              date: '2025-05-05T14:25:00Z',
              content: 'The technical approach is solid, but we should strengthen the past performance section with more quantifiable metrics.',
              status: 'addressed'
            },
            {
              id: 'rev-2',
              reviewer: 'Jane Doe',
              date: '2025-05-07T09:15:00Z',
              content: 'Cost breakdown needs more detail on the maintenance and support allocation.',
              status: 'pending'
            }
          ]
        });
      }
    } catch (error) {
      console.error('Error fetching proposal details:', error);
      setError('Failed to load proposal details. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleProposalSelect = (proposalId) => {
    fetchProposalDetails(proposalId);
  };

  const handleFeedbackChange = (e) => {
    setFeedback(e.target.value);
  };

  const handleSubmitFeedback = async (e) => {
    e.preventDefault();
    
    if (!selectedProposal) {
      setError('No proposal selected for review.');
      return;
    }
    
    if (!feedback.trim()) {
      setError('Please enter feedback before submitting.');
      return;
    }
    
    setSubmitting(true);
    setError('');
    setSuccessMessage('');
    
    try {
      const reviewData = {
        content: feedback,
        reviewer: 'Current User' // In a real app, this would be the logged-in user
      };
      
      await ApiService.review.create(selectedProposal.id, reviewData);
      
      // Add the new review to the selected proposal
      setSelectedProposal({
        ...selectedProposal,
        reviews: [
          ...(selectedProposal.reviews || []),
          {
            id: `new-${Date.now()}`,
            reviewer: 'Current User',
            date: new Date().toISOString(),
            content: feedback,
            status: 'pending'
          }
        ]
      });
      
      // Update the review count in the proposals list
      setProposals(proposals.map(proposal => 
        proposal.id === selectedProposal.id
          ? { ...proposal, reviewCount: (proposal.reviewCount || 0) + 1 }
          : proposal
      ));
      
      setFeedback('');
      setSuccessMessage('Feedback submitted successfully!');
      
      // Hide success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    } catch (error) {
      console.error('Error submitting feedback:', error);
      setError('Failed to submit feedback. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };

  const formatDateTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) + 
           ' at ' + 
           date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const getReviewStatusClass = (status) => {
    switch (status.toLowerCase()) {
      case 'addressed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Review Proposals</h1>
      
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 rounded-md p-4">
          {error}
        </div>
      )}
      
      {successMessage && (
        <div className="bg-green-50 border border-green-200 text-green-800 rounded-md p-4">
          {successMessage}
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">Proposals for Review</h2>
            </div>
            
            {loading && !selectedProposal && proposals.length === 0 ? (
              <div className="p-6 text-center">
                <p className="text-gray-500">Loading proposals...</p>
              </div>
            ) : proposals.length === 0 ? (
              <div className="p-6 text-center">
                <p className="text-gray-500">No proposals available for review.</p>
              </div>
            ) : (
              <ul className="divide-y divide-gray-200">
                {proposals.map((proposal) => (
                  <li 
                    key={proposal.id}
                    className={`p-4 cursor-pointer hover:bg-gray-50 ${
                      selectedProposal?.id === proposal.id ? 'bg-primary-50' : ''
                    }`}
                    onClick={() => handleProposalSelect(proposal.id)}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-gray-900">{proposal.title}</h3>
                        <p className="text-sm text-gray-500">Client: {proposal.client}</p>
                        <p className="text-sm text-gray-500">Due: {formatDate(proposal.dueDate)}</p>
                      </div>
                      <div className="text-sm text-gray-500">
                        {proposal.reviewCount} {proposal.reviewCount === 1 ? 'review' : 'reviews'}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
        
        <div className="lg:col-span-2">
          {selectedProposal ? (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-medium text-gray-900">{selectedProposal.title}</h2>
                <p className="text-sm text-gray-500">
                  Client: {selectedProposal.client} | Due: {formatDate(selectedProposal.dueDate)}
                </p>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="prose max-w-none">
                  {selectedProposal.sections.map((section, index) => (
                    <div key={index} className="mb-6">
                      <h3>{section.title}</h3>
                      <p>{section.content}</p>
                    </div>
                  ))}
                </div>
                
                <div className="border-t border-gray-200 pt-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Feedback & Reviews</h3>
                  
                  {selectedProposal.reviews && selectedProposal.reviews.length > 0 ? (
                    <ul className="space-y-4 mb-6">
                      {selectedProposal.reviews.map((review) => (
                        <li key={review.id} className="bg-gray-50 p-4 rounded-lg">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-medium text-gray-900">{review.reviewer}</p>
                              <p className="text-sm text-gray-500">{formatDateTime(review.date)}</p>
                            </div>
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${getReviewStatusClass(review.status)}`}>
                              {review.status}
                            </span>
                          </div>
                          <p className="mt-2 text-gray-700">{review.content}</p>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-gray-500 mb-6">No reviews yet. Be the first to provide feedback.</p>
                  )}
                  
                  <form onSubmit={handleSubmitFeedback}>
                    <div className="mb-4">
                      <label htmlFor="feedback" className="block text-sm font-medium text-gray-700 mb-2">
                        Add Your Feedback
                      </label>
                      <textarea
                        id="feedback"
                        rows={4}
                        value={feedback}
                        onChange={handleFeedbackChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="Enter your feedback or suggestions..."
                        required
                      />
                    </div>
                    <div className="flex justify-end">
                      <button
                        type="submit"
                        disabled={submitting}
                        className={`px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark ${
                          submitting ? 'opacity-50 cursor-not-allowed' : ''
                        }`}
                      >
                        {submitting ? 'Submitting...' : 'Submit Feedback'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
              <p className="text-gray-500">Select a proposal from the list to review.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReviewInterface;
