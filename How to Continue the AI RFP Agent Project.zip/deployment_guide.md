# AI RFP Agent - Deployment Guide

## Overview

This guide provides instructions for deploying the AI RFP Agent User Interface developed in Phase 4. The deployment process includes building the React application, configuring the environment, and setting up the necessary infrastructure.

## Prerequisites

- Node.js 16.x or higher
- npm or yarn package manager
- Access to the deployment environment
- Backend API endpoint information

## Environment Setup

### Development Environment

1. Clone the repository:
   ```bash
   git clone https://github.com/your-org/ai-rfp-agent-ui.git
   cd ai-rfp-agent-ui
   ```

2. Install dependencies:
   ```bash
   npm install
   # or
   yarn install
   ```

3. Create a `.env.development` file with the following variables:
   ```
   REACT_APP_API_BASE_URL=http://localhost:5000/api
   REACT_APP_AUTH_STORAGE_KEY=ai_rfp_agent_auth
   REACT_APP_DEFAULT_TIMEOUT=30000
   ```

4. Start the development server:
   ```bash
   npm start
   # or
   yarn start
   ```

### Production Environment

1. Create a `.env.production` file with the following variables:
   ```
   REACT_APP_API_BASE_URL=https://api.yourcompany.com/ai-rfp-agent/api
   REACT_APP_AUTH_STORAGE_KEY=ai_rfp_agent_auth
   REACT_APP_DEFAULT_TIMEOUT=30000
   ```

2. Build the production bundle:
   ```bash
   npm run build
   # or
   yarn build
   ```

3. The build output will be in the `build` directory, ready for deployment.

## Deployment Options

### Option 1: Static Web Server

1. Copy the contents of the `build` directory to your web server's document root:
   ```bash
   cp -r build/* /var/www/html/
   ```

2. Configure your web server (Apache, Nginx, etc.) to serve the application and handle client-side routing.

#### Nginx Configuration Example:
```nginx
server {
    listen 80;
    server_name rfp-agent.yourcompany.com;
    root /var/www/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

### Option 2: Docker Deployment

1. Create a `Dockerfile` in the project root:
```dockerfile
FROM node:16-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/build /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

2. Create an `nginx.conf` file:
```
server {
    listen 80;
    location / {
        root /usr/share/nginx/html;
        index index.html index.htm;
        try_files $uri $uri/ /index.html;
    }
}
```

3. Build and run the Docker container:
```bash
docker build -t ai-rfp-agent-ui .
docker run -p 80:80 ai-rfp-agent-ui
```

### Option 3: Cloud Deployment (AWS S3 + CloudFront)

1. Build the production bundle:
```bash
npm run build
```

2. Deploy to S3:
```bash
aws s3 sync build/ s3://your-bucket-name --delete
```

3. Configure CloudFront to serve the S3 bucket with proper caching and routing settings.

## Post-Deployment Verification

After deployment, verify the following:

1. Application loads correctly at the deployed URL
2. Authentication works properly
3. API communication is successful
4. All features function as expected
5. No console errors are present

## Troubleshooting

### Common Deployment Issues

1. **Routing Issues**: Ensure your web server is configured to handle client-side routing by redirecting all requests to index.html.

2. **API Connection Issues**: Verify that the `REACT_APP_API_BASE_URL` environment variable is set correctly and the API is accessible from the deployed environment.

3. **CORS Issues**: Ensure the backend API allows requests from the domain where the UI is deployed.

4. **Asset Loading Issues**: Check that all static assets are being served with the correct paths.

5. **Environment Variables**: Confirm that environment variables are properly set during the build process.

## Maintenance

### Updating the Deployment

1. Make changes to the codebase
2. Build a new production bundle
3. Deploy the new bundle following the same process as the initial deployment
4. Verify the update was successful

### Monitoring

1. Set up application monitoring to track:
   - Error rates
   - Page load times
   - API response times
   - User activity

2. Configure alerts for critical issues

## Rollback Procedure

In case of critical issues after deployment:

1. Identify the last stable version
2. Build the production bundle from that version
3. Deploy following the same process as the initial deployment
4. Verify the rollback was successful
