import axios from 'axios';

// API base URL
const API_BASE_URL = 'https://5000-ir3k5q4zt618zyxbw3ckg-b8915330.manus.computer/api';

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle 401 Unauthorized errors
    if (error.response && error.response.status === 401) {
      // Clear auth tokens
      localStorage.removeItem('authToken');
      sessionStorage.removeItem('authToken');
      
      // Redirect to login page if not already there
      if (!window.location.pathname.includes('/login')) {
        window.location.href = '/login';
      }
    }
    
    return Promise.reject(error);
  }
);

// API service with endpoints grouped by domain
const ApiService = {
  // Authentication endpoints
  auth: {
    login: (credentials) => apiClient.post('/auth/login', credentials),
    logout: () => apiClient.post('/auth/logout'),
    register: (userData) => apiClient.post('/auth/register', userData),
    getCurrentUser: () => apiClient.get('/auth/me'),
  },
  
  // RFP document endpoints
  rfp: {
    upload: (formData) => {
      const config = {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      };
      return apiClient.post('/rfp/upload', formData, config);
    },
    getAll: (params = {}) => apiClient.get('/rfp', { params }),
    getById: (id) => apiClient.get(`/rfp/${id}`),
    analyze: (id) => apiClient.post(`/rfp/${id}/analyze`),
    delete: (id) => apiClient.delete(`/rfp/${id}`),
  },
  
  // Proposal endpoints
  proposal: {
    generate: (data) => apiClient.post('/proposals/generate', data),
    getAll: (params = {}) => apiClient.get('/proposals', { params }),
    getById: (id) => apiClient.get(`/proposals/${id}`),
    update: (id, data) => apiClient.put(`/proposals/${id}`, data),
    delete: (id) => apiClient.delete(`/proposals/${id}`),
    getStatus: (type) => apiClient.get(`/proposals/status/${type}`),
  },
  
  // Knowledge base endpoints
  knowledgeBase: {
    search: (params = {}) => apiClient.get('/knowledge', { params }),
    getById: (id) => apiClient.get(`/knowledge/${id}`),
    create: (data) => apiClient.post('/knowledge', data),
    update: (id, data) => apiClient.put(`/knowledge/${id}`, data),
    delete: (id) => apiClient.delete(`/knowledge/${id}`),
  },
  
  // Review endpoints
  review: {
    create: (proposalId, data) => apiClient.post(`/proposals/${proposalId}/reviews`, data),
    update: (proposalId, reviewId, data) => apiClient.put(`/proposals/${proposalId}/reviews/${reviewId}`, data),
    delete: (proposalId, reviewId) => apiClient.delete(`/proposals/${proposalId}/reviews/${reviewId}`),
  },
  
  // User endpoints
  user: {
    getProfile: () => apiClient.get('/users/profile'),
    updateProfile: (data) => apiClient.put('/users/profile', data),
    changePassword: (data) => apiClient.put('/users/password', data),
  },
  
  // Analytics endpoints
  analytics: {
    getDashboard: () => apiClient.get('/analytics/dashboard'),
    getProposalMetrics: (params = {}) => apiClient.get('/analytics/proposals', { params }),
    getKnowledgeMetrics: (params = {}) => apiClient.get('/analytics/knowledge', { params }),
  },
};

export default ApiService;
