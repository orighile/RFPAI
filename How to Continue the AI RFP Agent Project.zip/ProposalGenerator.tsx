import React, { useState, useEffect } from 'react';
import ApiService from '../../services/ApiService';

const ProposalGenerator: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    rfpId: '',
    title: '',
    client: '',
    budget: '',
    dueDate: '',
    sections: ['executive_summary', 'technical_approach', 'past_performance', 'cost'],
    useKnowledgeBase: true,
    includeVisuals: true,
    toneStyle: 'professional'
  });
  const [rfpDocuments, setRfpDocuments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [generationStarted, setGenerationStarted] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationStatus, setGenerationStatus] = useState('');
  const [proposalId, setProposalId] = useState('');

  // Fetch RFP documents on component mount
  useEffect(() => {
    fetchRfpDocuments();
  }, []);

  // Poll for generation progress if generation has started
  useEffect(() => {
    let intervalId: NodeJS.Timeout | null = null;
    
    if (generationStarted && proposalId && generationProgress < 100) {
      intervalId = setInterval(checkGenerationProgress, 2000);
    }
    
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [generationStarted, proposalId, generationProgress]);

  const fetchRfpDocuments = async () => {
    setLoading(true);
    setError('');
    
    try {
      const response = await ApiService.rfp.getAll();
      
      if (response.data?.documents) {
        setRfpDocuments(response.data.documents);
      } else {
        // Fallback to sample data
        setRfpDocuments([
          { id: 'rfp-1', title: 'Weather System RFP', client: 'Sky Analytics Inc.', uploadDate: '2025-05-01T10:00:00Z' },
          { id: 'rfp-2', title: 'Federal Healthcare RFP', client: 'HHS', uploadDate: '2025-05-05T14:30:00Z' },
          { id: 'rfp-3', title: 'Sample RFP Document', client: 'Test Client', uploadDate: '2025-05-10T09:15:00Z' }
        ]);
      }
    } catch (error) {
      console.error('Error fetching RFP documents:', error);
      setError('Failed to load RFP documents. Please try again.');
      
      // Fallback to sample data
      setRfpDocuments([
        { id: 'rfp-1', title: 'Weather System RFP', client: 'Sky Analytics Inc.', uploadDate: '2025-05-01T10:00:00Z' },
        { id: 'rfp-2', title: 'Federal Healthcare RFP', client: 'HHS', uploadDate: '2025-05-05T14:30:00Z' },
        { id: 'rfp-3', title: 'Sample RFP Document', client: 'Test Client', uploadDate: '2025-05-10T09:15:00Z' }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked
    });
  };

  const handleSectionToggle = (section: string) => {
    setFormData({
      ...formData,
      sections: formData.sections.includes(section)
        ? formData.sections.filter(s => s !== section)
        : [...formData.sections, section]
    });
  };

  const handleRfpSelect = (rfpId: string) => {
    // Find the selected RFP document
    const selectedRfp = rfpDocuments.find((doc: any) => doc.id === rfpId);
    
    if (selectedRfp) {
      // Pre-fill form data based on selected RFP
      setFormData({
        ...formData,
        rfpId,
        title: `Proposal for ${selectedRfp.title}`,
        client: selectedRfp.client
      });
    }
  };

  const handleNextStep = () => {
    // Validate current step before proceeding
    if (validateCurrentStep()) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePreviousStep = () => {
    setCurrentStep(currentStep - 1);
  };

  const validateCurrentStep = () => {
    switch (currentStep) {
      case 1:
        if (!formData.rfpId) {
          alert('Please select an RFP document');
          return false;
        }
        return true;
      
      case 2:
        if (!formData.title || !formData.client || !formData.dueDate) {
          alert('Please fill in all required fields');
          return false;
        }
        return true;
      
      case 3:
        if (formData.sections.length === 0) {
          alert('Please select at least one section to include');
          return false;
        }
        return true;
      
      default:
        return true;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateCurrentStep()) {
      return;
    }
    
    setLoading(true);
    setError('');
    setGenerationStarted(false);
    setGenerationProgress(0);
    setGenerationStatus('');
    
    try {
      const response = await ApiService.proposal.generate(formData);
      
      if (response.data?.proposalId) {
        setProposalId(response.data.proposalId);
        setGenerationStarted(true);
        setGenerationStatus('Proposal generation started');
        setGenerationProgress(5); // Initial progress
        
        // Start polling for progress
        checkGenerationProgress();
      } else {
        // Fallback for testing
        setProposalId('test-proposal-id');
        setGenerationStarted(true);
        setGenerationStatus('Proposal generation started');
        setGenerationProgress(5);
        
        // Simulate progress for testing
        simulateGenerationProgress();
      }
    } catch (error) {
      console.error('Error generating proposal:', error);
      setError('Failed to start proposal generation. Please try again.');
      
      // Fallback for testing
      setProposalId('test-proposal-id');
      setGenerationStarted(true);
      setGenerationStatus('Proposal generation started');
      setGenerationProgress(5);
      
      // Simulate progress for testing
      simulateGenerationProgress();
    } finally {
      setLoading(false);
    }
  };

  const checkGenerationProgress = async () => {
    if (!proposalId) return;
    
    try {
      const response = await ApiService.proposal.getById(proposalId);
      
      if (response.data?.progress) {
        setGenerationProgress(response.data.progress);
        setGenerationStatus(response.data.status || 'Processing');
        
        if (response.data.progress >= 100) {
          // Redirect to proposal view page
          setTimeout(() => {
            window.location.href = `/proposals/${proposalId}`;
          }, 1000);
        }
      }
    } catch (error) {
      console.error('Error checking generation progress:', error);
    }
  };

  const simulateGenerationProgress = () => {
    let progress = 5;
    const interval = setInterval(() => {
      progress += Math.floor(Math.random() * 10) + 5;
      
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        
        setGenerationProgress(progress);
        setGenerationStatus('Completed');
        
        // Redirect to proposal view page
        setTimeout(() => {
          window.location.href = `/proposals/${proposalId}`;
        }, 1000);
      } else {
        setGenerationProgress(progress);
        setGenerationStatus(getStatusForProgress(progress));
      }
    }, 2000);
  };

  const getStatusForProgress = (progress: number) => {
    if (progress < 20) return 'Analyzing RFP document...';
    if (progress < 40) return 'Retrieving knowledge base insights...';
    if (progress < 60) return 'Generating content sections...';
    if (progress < 80) return 'Applying compliance checks...';
    if (progress < 95) return 'Finalizing proposal...';
    return 'Completed';
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Generate New Proposal</h1>
      
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 rounded-md p-4">
          {error}
        </div>
      )}
      
      {generationStarted ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-medium text-gray-900 mb-4">Generating Proposal</h2>
          
          <div className="mb-4">
            <div className="flex justify-between text-sm text-gray-500 mb-1">
              <span>{generationStatus}</span>
              <span>{generationProgress}% Complete</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="h-2.5 rounded-full bg-primary"
                style={{ width: `${generationProgress}%` }}
              ></div>
            </div>
          </div>
          
          <p className="text-gray-500 text-sm">
            Your proposal is being generated. This may take a few minutes. You will be redirected to the proposal view page when it's complete.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="border-b border-gray-200">
            <div className="p-4">
              <div className="flex items-center">
                {[1, 2, 3, 4].map((step) => (
                  <React.Fragment key={step}>
                    <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                      currentStep === step
                        ? 'bg-primary text-white'
                        : currentStep > step
                        ? 'bg-primary-light text-primary'
                        : 'bg-gray-200 text-gray-500'
                    }`}>
                      {step}
                    </div>
                    {step < 4 && (
                      <div className={`h-1 w-12 ${
                        currentStep > step ? 'bg-primary' : 'bg-gray-200'
                      }`}></div>
                    )}
                  </React.Fragment>
                ))}
              </div>
              <div className="flex justify-between mt-2">
                <div className="text-xs text-gray-500">Select RFP</div>
                <div className="text-xs text-gray-500">Basic Info</div>
                <div className="text-xs text-gray-500">Content</div>
                <div className="text-xs text-gray-500">Review</div>
              </div>
            </div>
          </div>
          
          <form onSubmit={handleSubmit}>
            <div className="p-6">
              {currentStep === 1 && (
                <div className="space-y-6">
                  <h2 className="text-xl font-medium text-gray-900">Select RFP Document</h2>
                  
                  {loading ? (
                    <div className="text-center py-4">
                      <p className="text-gray-500">Loading RFP documents...</p>
                    </div>
                  ) : rfpDocuments.length === 0 ? (
                    <div className="text-center py-4">
                      <p className="text-gray-500">No RFP documents found. Please upload an RFP document first.</p>
                      <button
                        type="button"
                        onClick={() => window.location.href = '/documents/upload'}
                        className="mt-4 px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark"
                      >
                        Upload RFP Document
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <p className="text-gray-500">
                        Select an RFP document to generate a proposal for. The AI will analyze the document and create a tailored response.
                      </p>
                      
                      <div className="grid gap-4">
                        {rfpDocuments.map((doc: any) => (
                          <div 
                            key={doc.id}
                            className={`border rounded-lg p-4 cursor-pointer ${
                              formData.rfpId === doc.id
                                ? 'border-primary bg-primary-50'
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                            onClick={() => handleRfpSelect(doc.id)}
                          >
                            <div className="flex items-start justify-between">
                              <div>
                                <h3 className="font-medium text-gray-900">{doc.title}</h3>
                                <p className="text-sm text-gray-500">Client: {doc.client}</p>
                                <p className="text-sm text-gray-500">Uploaded: {formatDate(doc.uploadDate)}</p>
                              </div>
                              <div className="flex h-5 items-center">
                                <input
                                  type="radio"
                                  name="rfpDocument"
                                  checked={formData.rfpId === doc.id}
                                  onChange={() => handleRfpSelect(doc.id)}
                                  className="h-4 w-4 text-primary focus:ring-primary border-gray-300"
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
              
              {currentStep === 2 && (
                <div className="space-y-6">
                  <h2 className="text-xl font-medium text-gray-900">Basic Information</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                        Proposal Title <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        id="title"
                        name="title"
                        value={formData.title}
                        onChange={handleInputChange}
                        required
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="client" className="block text-sm font-medium text-gray-700">
                        Client Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        id="client"
                        name="client"
                        value={formData.client}
                        onChange={handleInputChange}
                        required
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="budget" className="block text-sm font-medium text-gray-700">
                        Budget (USD)
                      </label>
                      <input
                        type="number"
                        id="budget"
                      
(Content truncated due to size limit. Use line ranges to read in chunks)