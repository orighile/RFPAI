import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import DocumentUpload from '../components/documents/DocumentUpload';
import { RfpProvider } from '../contexts/RfpContext';

// Mock the API service
jest.mock('../services/ApiService', () => ({
  rfp: {
    upload: jest.fn(),
  },
}));

describe('DocumentUpload Component', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
  });

  test('renders document upload form correctly', () => {
    render(
      <RfpProvider>
        <DocumentUpload />
      </RfpProvider>
    );
    
    // Check if important elements are rendered
    expect(screen.getByText(/Upload RFP Document/i)).toBeInTheDocument();
    expect(screen.getByText(/Drag and drop your files here/i)).toBeInTheDocument();
    expect(screen.getByText(/or click to browse/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Upload/i })).toBeInTheDocument();
  });

  test('handles file selection', async () => {
    render(
      <RfpProvider>
        <DocumentUpload />
      </RfpProvider>
    );
    
    const file = new File(['test content'], 'test-rfp.pdf', { type: 'application/pdf' });
    const fileInput = screen.getByTestId('file-input');
    
    Object.defineProperty(fileInput, 'files', {
      value: [file],
    });
    
    fireEvent.change(fileInput);
    
    await waitFor(() => {
      expect(screen.getByText('test-rfp.pdf')).toBeInTheDocument();
    });
  });

  test('handles form submission', async () => {
    const mockUpload = jest.fn().mockResolvedValue({ data: { id: '123', name: 'test-rfp.pdf' } });
    require('../services/ApiService').rfp.upload = mockUpload;
    
    render(
      <RfpProvider>
        <DocumentUpload />
      </RfpProvider>
    );
    
    const file = new File(['test content'], 'test-rfp.pdf', { type: 'application/pdf' });
    const fileInput = screen.getByTestId('file-input');
    
    Object.defineProperty(fileInput, 'files', {
      value: [file],
    });
    
    fireEvent.change(fileInput);
    
    const uploadButton = screen.getByRole('button', { name: /Upload/i });
    fireEvent.click(uploadButton);
    
    await waitFor(() => {
      expect(mockUpload).toHaveBeenCalled();
    });
  });

  test('displays error message when no file is selected', async () => {
    render(
      <RfpProvider>
        <DocumentUpload />
      </RfpProvider>
    );
    
    const uploadButton = screen.getByRole('button', { name: /Upload/i });
    fireEvent.click(uploadButton);
    
    await waitFor(() => {
      expect(screen.getByText(/Please select a file to upload/i)).toBeInTheDocument();
    });
  });
});
