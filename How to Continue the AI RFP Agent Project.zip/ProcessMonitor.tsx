import React, { useState, useEffect } from 'react';
import ApiService from '../../services/ApiService';

const ProcessMonitor: React.FC = () => {
  const [activeProcesses, setActiveProcesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [refreshInterval, setRefreshInterval] = useState(30); // seconds
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    fetchActiveProcesses();
    
    // Set up auto-refresh if enabled
    let intervalId: NodeJS.Timeout | null = null;
    if (autoRefresh) {
      intervalId = setInterval(fetchActiveProcesses, refreshInterval * 1000);
    }
    
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [autoRefresh, refreshInterval]);

  const fetchActiveProcesses = async () => {
    setLoading(true);
    setError('');
    
    try {
      const response = await ApiService.proposal.getStatus('active');
      
      if (response.data?.processes) {
        setActiveProcesses(response.data.processes);
      } else {
        // Fallback to sample data
        setActiveProcesses([
          {
            id: 'proc-1',
            type: 'proposal_generation',
            title: 'Weather System Proposal for Sky Analytics',
            status: 'processing',
            progress: 65,
            startedAt: '2025-05-16T01:30:00Z',
            estimatedCompletion: '2025-05-16T02:15:00Z'
          },
          {
            id: 'proc-2',
            type: 'rfp_analysis',
            title: 'Federal Healthcare RFP Analysis',
            status: 'queued',
            progress: 0,
            startedAt: '2025-05-16T01:45:00Z',
            estimatedCompletion: '2025-05-16T02:00:00Z'
          },
          {
            id: 'proc-3',
            type: 'knowledge_extraction',
            title: 'Extracting insights from previous proposals',
            status: 'completed',
            progress: 100,
            startedAt: '2025-05-16T01:15:00Z',
            estimatedCompletion: '2025-05-16T01:40:00Z',
            completedAt: '2025-05-16T01:38:00Z'
          }
        ]);
      }
    } catch (error) {
      console.error('Error fetching active processes:', error);
      setError('Failed to load active processes. Please try again.');
      
      // Fallback to sample data
      setActiveProcesses([
        {
          id: 'proc-1',
          type: 'proposal_generation',
          title: 'Weather System Proposal for Sky Analytics',
          status: 'processing',
          progress: 65,
          startedAt: '2025-05-16T01:30:00Z',
          estimatedCompletion: '2025-05-16T02:15:00Z'
        },
        {
          id: 'proc-2',
          type: 'rfp_analysis',
          title: 'Federal Healthcare RFP Analysis',
          status: 'queued',
          progress: 0,
          startedAt: '2025-05-16T01:45:00Z',
          estimatedCompletion: '2025-05-16T02:00:00Z'
        },
        {
          id: 'proc-3',
          type: 'knowledge_extraction',
          title: 'Extracting insights from previous proposals',
          status: 'completed',
          progress: 100,
          startedAt: '2025-05-16T01:15:00Z',
          estimatedCompletion: '2025-05-16T01:40:00Z',
          completedAt: '2025-05-16T01:38:00Z'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleRefreshNow = () => {
    fetchActiveProcesses();
  };

  const handleToggleAutoRefresh = () => {
    setAutoRefresh(!autoRefresh);
  };

  const handleRefreshIntervalChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setRefreshInterval(Number(e.target.value));
  };

  const handleViewProcess = (processId: string) => {
    // In a real implementation, this would navigate to a detailed view
    alert(`Viewing process details for: ${processId}`);
  };

  const handleCancelProcess = async (processId: string) => {
    if (confirm('Are you sure you want to cancel this process?')) {
      try {
        await ApiService.proposal.update(processId, { status: 'cancelled' });
        
        // Update the local state to reflect the cancellation
        setActiveProcesses(prevProcesses => 
          prevProcesses.map(process => 
            process.id === processId 
              ? { ...process, status: 'cancelled' } 
              : process
          )
        );
        
        alert('Process cancelled successfully');
      } catch (error) {
        console.error('Error cancelling process:', error);
        alert('Failed to cancel process. Please try again.');
      }
    }
  };

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getProcessTypeLabel = (type: string) => {
    switch (type) {
      case 'proposal_generation':
        return 'Proposal Generation';
      case 'rfp_analysis':
        return 'RFP Analysis';
      case 'knowledge_extraction':
        return 'Knowledge Extraction';
      default:
        return type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    }
  };

  const getStatusClass = (status: string) => {
    switch (status.toLowerCase()) {
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'queued':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getProgressBarColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'processing':
        return 'bg-blue-500';
      case 'queued':
        return 'bg-yellow-500';
      case 'completed':
        return 'bg-green-500';
      case 'cancelled':
        return 'bg-red-500';
      case 'failed':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Process Monitor</h1>
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <label htmlFor="refreshInterval" className="mr-2 text-sm text-gray-700">
              Refresh every:
            </label>
            <select
              id="refreshInterval"
              value={refreshInterval}
              onChange={handleRefreshIntervalChange}
              className="border border-gray-300 rounded-md text-sm p-1"
              disabled={!autoRefresh}
            >
              <option value="10">10s</option>
              <option value="30">30s</option>
              <option value="60">1m</option>
              <option value="300">5m</option>
            </select>
          </div>
          <div className="flex items-center">
            <input
              type="checkbox"
              id="autoRefresh"
              checked={autoRefresh}
              onChange={handleToggleAutoRefresh}
              className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
            />
            <label htmlFor="autoRefresh" className="ml-2 text-sm text-gray-700">
              Auto-refresh
            </label>
          </div>
          <button
            onClick={handleRefreshNow}
            className="px-3 py-1 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 flex items-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            Refresh Now
          </button>
        </div>
      </div>
      
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 rounded-md p-4">
          {error}
        </div>
      )}
      
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Active Processes</h2>
        </div>
        
        {loading && activeProcesses.length === 0 ? (
          <div className="p-6 text-center">
            <p className="text-gray-500">Loading active processes...</p>
          </div>
        ) : activeProcesses.length === 0 ? (
          <div className="p-6 text-center">
            <p className="text-gray-500">No active processes found.</p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {activeProcesses.map((process: any) => (
              <li key={process.id} className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="flex items-center">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusClass(process.status)} mr-2`}>
                        {process.status}
                      </span>
                      <span className="text-sm text-gray-500">
                        {getProcessTypeLabel(process.type)}
                      </span>
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mt-1">{process.title}</h3>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleViewProcess(process.id)}
                      className="text-primary hover:text-primary-dark"
                    >
                      View
                    </button>
                    {['processing', 'queued'].includes(process.status.toLowerCase()) && (
                      <button
                        onClick={() => handleCancelProcess(process.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
                
                <div className="mb-2">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>Progress: {process.progress}%</span>
                    {process.status.toLowerCase() === 'processing' && (
                      <span>
                        Est. completion: {formatDateTime(process.estimatedCompletion)}
                      </span>
                    )}
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className={`h-2.5 rounded-full ${getProgressBarColor(process.status)}`}
                      style={{ width: `${process.progress}%` }}
                    ></div>
                  </div>
                </div>
                
                <div className="text-xs text-gray-500">
                  <span>Started: {formatDateTime(process.startedAt)}</span>
                  {process.completedAt && (
                    <span className="ml-4">Completed: {formatDateTime(process.completedAt)}</span>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default ProcessMonitor;
