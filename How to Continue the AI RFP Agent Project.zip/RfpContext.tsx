import React, { createContext, useContext, useState, useEffect } from 'react';
import ApiService from '../services/ApiService';

// Define the RFP context type
interface RfpContextType {
  rfps: any[];
  isLoading: boolean;
  error: string | null;
  uploadRfp: (formData: FormData) => Promise<any>;
  analyzeRfp: (rfpId: string) => Promise<any>;
  fetchRfps: (params?: any) => Promise<void>;
  deleteRfp: (id: string) => Promise<void>;
  currentRfp: any | null;
  setCurrentRfp: (rfp: any) => void;
}

// Create the RFP context
const RfpContext = createContext<RfpContextType>({
  rfps: [],
  isLoading: false,
  error: null,
  uploadRfp: async () => ({}),
  analyzeRfp: async () => ({}),
  fetchRfps: async () => {},
  deleteRfp: async () => {},
  currentRfp: null,
  setCurrentRfp: () => {},
});

// RFP provider component
export const RfpProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [rfps, setRfps] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentRfp, setCurrentRfp] = useState<any | null>(null);

  // Fetch all RFPs
  const fetchRfps = async (params?: any) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.rfp.getAll(params);
      setRfps(response.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch RFPs');
      console.error('Error fetching RFPs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Upload a new RFP
  const uploadRfp = async (formData: FormData) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.rfp.upload(formData);
      setRfps((prevRfps) => [...prevRfps, response.data]);
      return response.data;
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to upload RFP');
      console.error('Error uploading RFP:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Analyze an RFP
  const analyzeRfp = async (rfpId: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.rfp.analyze(rfpId);
      // Update the RFP in the list with analysis results
      setRfps((prevRfps) =>
        prevRfps.map((rfp) => (rfp.id === rfpId ? { ...rfp, analysis: response.data } : rfp))
      );
      return response.data;
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to analyze RFP');
      console.error('Error analyzing RFP:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Delete an RFP
  const deleteRfp = async (id: string) => {
    setIsLoading(true);
    setError(null);
    try {
      await ApiService.rfp.delete(id);
      setRfps((prevRfps) => prevRfps.filter((rfp) => rfp.id !== id));
      if (currentRfp && currentRfp.id === id) {
        setCurrentRfp(null);
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to delete RFP');
      console.error('Error deleting RFP:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <RfpContext.Provider
      value={{
        rfps,
        isLoading,
        error,
        uploadRfp,
        analyzeRfp,
        fetchRfps,
        deleteRfp,
        currentRfp,
        setCurrentRfp,
      }}
    >
      {children}
    </RfpContext.Provider>
  );
};

// Custom hook to use the RFP context
export const useRfp = () => useContext(RfpContext);
