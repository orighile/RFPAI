import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import ApiService from '../services/ApiService';

// Mock axios
jest.mock('axios', () => ({
  create: jest.fn(() => ({
    interceptors: {
      request: { use: jest.fn(), eject: jest.fn() },
      response: { use: jest.fn(), eject: jest.fn() }
    },
    get: jest.fn(),
    post: jest.fn(),
    put: jest.fn(),
    delete: jest.fn()
  })),
}));

describe('ApiService', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
    localStorage.clear();
  });

  test('adds auth token to requests when available', async () => {
    // Setup
    const mockAxios = require('axios').create();
    localStorage.setItem('auth_token', 'test-token');
    
    // Get the request interceptor callback
    const requestInterceptor = mockAxios.interceptors.request.use.mock.calls[0][0];
    
    // Create a mock config object
    const config = { headers: {} };
    
    // Call the interceptor
    const result = requestInterceptor(config);
    
    // Verify token was added
    expect(result.headers['Authorization']).toBe('Bearer test-token');
  });

  test('does not add auth token when not available', async () => {
    // Setup
    const mockAxios = require('axios').create();
    
    // Get the request interceptor callback
    const requestInterceptor = mockAxios.interceptors.request.use.mock.calls[0][0];
    
    // Create a mock config object
    const config = { headers: {} };
    
    // Call the interceptor
    const result = requestInterceptor(config);
    
    // Verify token was not added
    expect(result.headers['Authorization']).toBeUndefined();
  });

  test('handles 401 errors by redirecting to login', async () => {
    // Setup
    const mockAxios = require('axios').create();
    localStorage.setItem('auth_token', 'test-token');
    
    // Mock window.location
    const originalLocation = window.location;
    delete window.location;
    window.location = { href: '' };
    
    // Get the response interceptor error callback
    const responseErrorInterceptor = mockAxios.interceptors.response.use.mock.calls[0][1];
    
    // Create a mock error object with 401 status
    const error = {
      response: {
        status: 401
      }
    };
    
    // Call the interceptor and catch the rejection
    try {
      await responseErrorInterceptor(error);
    } catch (e) {
      // Expected to throw
    }
    
    // Verify token was removed and redirect happened
    expect(localStorage.getItem('auth_token')).toBeNull();
    expect(window.location.href).toBe('/login');
    
    // Restore window.location
    window.location = originalLocation;
  });

  test('auth.login calls the correct endpoint', async () => {
    // Setup
    const mockAxios = require('axios').create();
    mockAxios.post.mockResolvedValue({ data: { token: 'test-token', user: { id: '1' } } });
    
    // Call the method
    await ApiService.auth.login({ email: 'test@example.com', password: 'password' });
    
    // Verify correct endpoint was called with correct data
    expect(mockAxios.post).toHaveBeenCalledWith('/auth/login', { 
      email: 'test@example.com', 
      password: 'password' 
    });
  });

  test('rfp.upload calls the correct endpoint with form data', async () => {
    // Setup
    const mockAxios = require('axios').create();
    mockAxios.post.mockResolvedValue({ data: { id: '1' } });
    
    const formData = new FormData();
    formData.append('file', new Blob(['test']), 'test.pdf');
    
    // Call the method
    await ApiService.rfp.upload(formData);
    
    // Verify correct endpoint was called with correct data and headers
    expect(mockAxios.post).toHaveBeenCalledWith('/rfp/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  });

  test('proposal.generate calls the correct endpoint', async () => {
    // Setup
    const mockAxios = require('axios').create();
    mockAxios.post.mockResolvedValue({ data: { id: '1' } });
    
    const proposalData = {
      rfpId: 'rfp1',
      title: 'Test Proposal',
      settings: { includeVisuals: true }
    };
    
    // Call the method
    await ApiService.proposal.generate(proposalData);
    
    // Verify correct endpoint was called with correct data
    expect(mockAxios.post).toHaveBeenCalledWith('/proposal/generate', proposalData);
  });

  test('knowledgeBase.search calls the correct endpoint with params', async () => {
    // Setup
    const mockAxios = require('axios').create();
    mockAxios.get.mockResolvedValue({ data: [] });
    
    const searchParams = {
      query: 'technical approach',
      category: 'best_practices',
      sortBy: 'relevance'
    };
    
    // Call the method
    await ApiService.knowledgeBase.search(searchParams);
    
    // Verify correct endpoint was called with correct params
    expect(mockAxios.get).toHaveBeenCalledWith('/knowledge', { 
      params: searchParams 
    });
  });
});
