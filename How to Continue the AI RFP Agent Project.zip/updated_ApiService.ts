// Update the API base URL to point to our running backend
import axios from 'axios';

// Base API URL - configured to point to our running Flask backend
const API_BASE_URL = 'https://5000-ir3k5q4zt618zyxbw3ckg-b8915330.manus.computer/api';

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for adding auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for handling common errors
apiClient.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // Handle authentication errors
    if (error.response && error.response.status === 401) {
      // Redirect to login or refresh token
      localStorage.removeItem('auth_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// API service functions - aligned with our Flask backend endpoints
const ApiService = {
  // Auth endpoints
  auth: {
    login: (credentials) => apiClient.post('/auth/login', credentials),
    register: (userData) => apiClient.post('/auth/register', userData),
    logout: () => apiClient.post('/auth/logout'),
    getCurrentUser: () => apiClient.get('/auth/me'),
  },
  
  // RFP endpoints
  rfp: {
    upload: (formData) => apiClient.post('/rfp/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }),
    analyze: (rfpId, data) => apiClient.post(`/rfp/${rfpId}/analyze`, data),
    getAll: (params) => apiClient.get('/rfp', { params }),
    getById: (id) => apiClient.get(`/rfp/${id}`),
    delete: (id) => apiClient.delete(`/rfp/${id}`),
  },
  
  // Proposal endpoints
  proposal: {
    generate: (data) => apiClient.post('/proposal/generate', data),
    getAll: (params) => apiClient.get('/proposal', { params }),
    getById: (id) => apiClient.get(`/proposal/${id}`),
    update: (id, data) => apiClient.put(`/proposal/${id}`, data),
    delete: (id) => apiClient.delete(`/proposal/${id}`),
    getStatus: (id) => apiClient.get(`/proposal/${id}/status`),
  },
  
  // Review endpoints
  review: {
    create: (proposalId, reviewData) => apiClient.post(`/proposal/${proposalId}/review`, reviewData),
    getAll: (proposalId) => apiClient.get(`/proposal/${proposalId}/review`),
    update: (proposalId, reviewId, reviewData) => apiClient.put(`/proposal/${proposalId}/review/${reviewId}`, reviewData),
    delete: (proposalId, reviewId) => apiClient.delete(`/proposal/${proposalId}/review/${reviewId}`),
  },
  
  // Knowledge base endpoints
  knowledgeBase: {
    search: (params) => apiClient.get('/knowledge', { params }),
    getById: (id) => apiClient.get(`/knowledge/${id}`),
    create: (data) => apiClient.post('/knowledge', data),
    update: (id, data) => apiClient.put(`/knowledge/${id}`, data),
    delete: (id) => apiClient.delete(`/knowledge/${id}`),
    getCategories: () => apiClient.get('/knowledge/categories'),
  },
  
  // Health check endpoint
  health: {
    check: () => apiClient.get('/health'),
  }
};

export default ApiService;
