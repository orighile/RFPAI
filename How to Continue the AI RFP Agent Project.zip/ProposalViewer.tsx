import React, { useState, useEffect } from 'react';
import ApiService from '../../services/ApiService';

const ProposalViewer: React.FC = () => {
  const [proposal, setProposal] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('overview');
  const [feedback, setFeedback] = useState('');
  const [submittingFeedback, setSubmittingFeedback] = useState(false);
  const [feedbackSuccess, setFeedbackSuccess] = useState(false);

  // Get proposal ID from URL
  const getProposalId = () => {
    // In a real implementation, this would use a router
    const urlParts = window.location.pathname.split('/');
    return urlParts[urlParts.indexOf('proposals') + 1] || 'sample-proposal';
  };

  useEffect(() => {
    fetchProposal();
  }, []);

  const fetchProposal = async () => {
    setLoading(true);
    setError('');
    
    try {
      const proposalId = getProposalId();
      const response = await ApiService.proposal.getById(proposalId);
      
      if (response.data) {
        setProposal(response.data);
      } else {
        // Fallback to sample data
        setProposal({
          id: proposalId,
          title: 'Phase 3 RAG Test Proposal for Sky Analytics',
          client: 'Sky Analytics Inc.',
          status: 'Submitted',
          dueDate: '2025-05-10',
          budget: '250000',
          rfpDocument: 'sample_rfp.txt',
          createdAt: '2025-04-15T10:30:00Z',
          sections: [
            {
              title: 'Executive Summary',
              content: 'This proposal outlines our approach to developing a cloud-based weather analytics system for Sky Analytics Inc. Our solution leverages advanced AI and real-time data processing to provide accurate forecasting with minimal latency.'
            },
            {
              title: 'Technical Approach',
              content: 'Our technical approach combines state-of-the-art machine learning models with scalable cloud infrastructure. We will implement a distributed processing system capable of handling extreme weather events with sub-second response times.'
            },
            {
              title: 'Past Performance',
              content: 'We have successfully delivered similar systems for three federal agencies, all of which have reported 99.9% uptime and 95% forecast accuracy improvements.'
            },
            {
              title: 'Cost Breakdown',
              content: 'The total project cost of $250,000 includes $150,000 for development, $50,000 for testing and deployment, and $50,000 for first-year maintenance and support.'
            }
          ],
          reviews: [
            {
              id: '1',
              reviewer: 'John Smith',
              date: '2025-04-20T14:25:00Z',
              content: 'The technical approach is solid, but we should strengthen the past performance section with more quantifiable metrics.',
              status: 'addressed'
            },
            {
              id: '2',
              reviewer: 'Jane Doe',
              date: '2025-04-22T09:15:00Z',
              content: 'Cost breakdown needs more detail on the maintenance and support allocation.',
              status: 'pending'
            }
          ]
        });
      }
    } catch (error) {
      console.error('Error fetching proposal:', error);
      setError('Failed to load proposal. Please try again.');
      
      // Fallback to sample data
      setProposal({
        id: getProposalId(),
        title: 'Phase 3 RAG Test Proposal for Sky Analytics',
        client: 'Sky Analytics Inc.',
        status: 'Submitted',
        dueDate: '2025-05-10',
        budget: '250000',
        rfpDocument: 'sample_rfp.txt',
        createdAt: '2025-04-15T10:30:00Z',
        sections: [
          {
            title: 'Executive Summary',
            content: 'This proposal outlines our approach to developing a cloud-based weather analytics system for Sky Analytics Inc. Our solution leverages advanced AI and real-time data processing to provide accurate forecasting with minimal latency.'
          },
          {
            title: 'Technical Approach',
            content: 'Our technical approach combines state-of-the-art machine learning models with scalable cloud infrastructure. We will implement a distributed processing system capable of handling extreme weather events with sub-second response times.'
          },
          {
            title: 'Past Performance',
            content: 'We have successfully delivered similar systems for three federal agencies, all of which have reported 99.9% uptime and 95% forecast accuracy improvements.'
          },
          {
            title: 'Cost Breakdown',
            content: 'The total project cost of $250,000 includes $150,000 for development, $50,000 for testing and deployment, and $50,000 for first-year maintenance and support.'
          }
        ],
        reviews: [
          {
            id: '1',
            reviewer: 'John Smith',
            date: '2025-04-20T14:25:00Z',
            content: 'The technical approach is solid, but we should strengthen the past performance section with more quantifiable metrics.',
            status: 'addressed'
          },
          {
            id: '2',
            reviewer: 'Jane Doe',
            date: '2025-04-22T09:15:00Z',
            content: 'Cost breakdown needs more detail on the maintenance and support allocation.',
            status: 'pending'
          }
        ]
      });
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  const handleFeedbackChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFeedback(e.target.value);
  };

  const handleSubmitFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!feedback.trim()) {
      alert('Please enter feedback before submitting');
      return;
    }
    
    setSubmittingFeedback(true);
    setFeedbackSuccess(false);
    
    try {
      const proposalId = proposal?.id || getProposalId();
      const reviewData = {
        content: feedback,
        reviewer: 'Current User' // In a real app, this would be the logged-in user
      };
      
      await ApiService.review.create(proposalId, reviewData);
      
      // Add the new review to the list
      setProposal({
        ...proposal,
        reviews: [
          ...(proposal?.reviews || []),
          {
            id: `new-${Date.now()}`,
            reviewer: 'Current User',
            date: new Date().toISOString(),
            content: feedback,
            status: 'pending'
          }
        ]
      });
      
      setFeedback('');
      setFeedbackSuccess(true);
      
      // Hide success message after 3 seconds
      setTimeout(() => {
        setFeedbackSuccess(false);
      }, 3000);
    } catch (error) {
      console.error('Error submitting feedback:', error);
      alert('Failed to submit feedback. Please try again.');
    } finally {
      setSubmittingFeedback(false);
    }
  };

  const handleDownloadProposal = () => {
    alert(`Downloading proposal: ${proposal?.title}`);
    // In a real implementation, this would trigger a download
    // window.location.href = `/api/proposals/${proposal?.id}/download`;
  };

  const handleEditProposal = () => {
    window.location.href = `/proposals/${proposal?.id}/edit`;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) + 
           ' at ' + 
           date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const getStatusClass = (status: string) => {
    switch (status.toLowerCase()) {
      case 'submitted':
        return 'bg-green-100 text-green-800';
      case 'in review':
        return 'bg-yellow-100 text-yellow-800';
      case 'draft':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getReviewStatusClass = (status: string) => {
    switch (status.toLowerCase()) {
      case 'addressed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {loading ? (
        <div className="text-center py-8">
          <p className="text-gray-500">Loading proposal...</p>
        </div>
      ) : error ? (
        <div className="bg-red-50 border border-red-200 text-red-800 rounded-md p-4">
          {error}
        </div>
      ) : proposal ? (
        <>
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">{proposal.title}</h1>
            <div className="flex space-x-2">
              <button 
                onClick={handleDownloadProposal}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 flex items-center"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Download
              </button>
              <button 
                onClick={handleEditProposal}
                className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark flex items-center"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
                Edit
              </button>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="text-sm font-medium text-gray-500">Client</p>
                <p className="text-lg font-medium text-gray-900">{proposal.client}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Status</p>
                <p className="mt-1">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusClass(proposal.status)}`}>
                    {proposal.status}
                  </span>
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Due Date</p>
                <p className="text-lg font-medium text-gray-900">{formatDate(proposal.dueDate)}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Budget</p>
                <p className="text-lg font-medium text-gray-900">${Number(proposal.budget).toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">RFP Document</p>
                <p className="text-lg font-medium text-gray-900">{proposal.rfpDocument}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Created</p>
                <p className="text-lg font-medium text-gray-900">{formatDate(proposal.createdAt)}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="border-b border-gray-200">
              <nav className="-mb-px flex">
                <button
                  onClick={() => handleTabChange('overview')}
                  className={`py-4 px-6 font-medium text-sm ${
                    activeTab === 'overview'
                      ? 'border-b-2 border-primary text-primary'
                      : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  Overview
                </button>
                <button
                  onClick={() => handleTabChange('content')}
                  className={`py-4 px-6 font-medium text-sm ${
                    activeTab === 'content'
                      ? 'border-b-2 border-primary text-primary'
                      : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  Content
                </button>
                <button
                  onClick={() => handleTabChange('reviews')}
                  className={`py-4 px-6 font-medium text-sm ${
                    activeTab === 'reviews'
                      ? 'border-b-2 border-primary text-primary'
                      : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  Reviews
                </button>
              </nav>
            </div>
            
            <div className="p-6">
              {activeTab === 'overview' && (
                <div className="prose max-w-none">
                  <h2>Proposal Overview</h2>
                  <p>
                    This proposal was generated based on the RFP document "{proposal.rfpDocument}" for {proposal.client}.
                    It includes a comprehensive response addressing all requirements specified in the RFP.
                  </p>
                  
                  <h3>Key Highlights</h3>
                  <ul>
                    <li>Tailored solution based on client requirements</li>
                    <li>Competitive pricing structure with detailed cost breakdown</li>
                    <li>Proven past performance with similar projects</li>
                    <li>Comprehensive risk mitigation strategy</li>
                  </ul>
                  
                  <h3>Next Steps</h3>
                  <p>
                    Review the proposal content in detail and provide feedback. Once all feedback has been addressed,
                    the proposal will be ready for final submission to the client.
                  </p>
                </div>
              )}
              
              {activeTab === 'content' && (
                <div className="space-y-8">
                  {proposal.sections.map((section: any, index: number) => (
                    <div key={index} className="prose max-w-none">
                      <h2>{section.title}</h2>
                      <p>{section.content}</p>
                    </div>
                  ))}
                </div>
              )}
              
              {activeTab === 'reviews' && (
                <div className="space-y-6">
                  <h2 className="text-xl font-medium text-gray-900">Feedback & Reviews</h2>
                  
                  {proposal.reviews && proposal.reviews.length > 0 ? (
                    <ul className="space-y-4">
                      {proposal.reviews.map((review: any) => (
                        <li key={review.id} className="bg-gray-50 p-4 rounded-lg">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-medium text-gray-900">{review.reviewer}</p>
                              <p classNam
(Content truncated due to size limit. Use line ranges to read in chunks)