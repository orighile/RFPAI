import React, { useState } from 'react';

const KnowledgeBaseManager: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [showAddForm, setShowAddForm] = useState(false);
  
  const [newEntry, setNewEntry] = useState({
    title: '',
    description: '',
    category: 'best_practices',
    keywords: '',
    source: ''
  });
  
  const categories = [
    { id: 'all', name: 'All Items' },
    { id: 'rfp_insights', name: 'RFP Insights' },
    { id: 'proposal_feedback', name: 'Proposal Feedback' },
    { id: 'best_practices', name: 'Best Practices' },
    { id: 'lessons_learned', name: 'Lessons Learned' }
  ];
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Search logic would go here
    console.log('Searching for:', searchQuery);
  };
  
  const handleAddEntry = (e: React.FormEvent) => {
    e.preventDefault();
    // Add entry logic would go here
    console.log('Adding new entry:', newEntry);
    setShowAddForm(false);
    setNewEntry({
      title: '',
      description: '',
      category: 'best_practices',
      keywords: '',
      source: ''
    });
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Knowledge Base Manager</h1>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary-dark"
        >
          {showAddForm ? 'Cancel' : 'Add New Entry'}
        </button>
      </div>
      
      {/* Add New Entry Form */}
      {showAddForm && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-900">Add New Knowledge Entry</h2>
          </div>
          <form onSubmit={handleAddEntry} className="p-6 space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Title
              </label>
              <input
                type="text"
                id="title"
                value={newEntry.title}
                onChange={(e) => setNewEntry({...newEntry, title: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Enter a descriptive title"
                required
              />
            </div>
            
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="description"
                value={newEntry.description}
                onChange={(e) => setNewEntry({...newEntry, description: e.target.value})}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Enter detailed knowledge information"
                required
              ></textarea>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select
                  id="category"
                  value={newEntry.category}
                  onChange={(e) => setNewEntry({...newEntry, category: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                  required
                >
                  <option value="rfp_insights">RFP Insights</option>
                  <option value="proposal_feedback">Proposal Feedback</option>
                  <option value="best_practices">Best Practices</option>
                  <option value="lessons_learned">Lessons Learned</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="source" className="block text-sm font-medium text-gray-700 mb-1">
                  Source
                </label>
                <input
                  type="text"
                  id="source"
                  value={newEntry.source}
                  onChange={(e) => setNewEntry({...newEntry, source: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                  placeholder="E.g., RFP ID, Proposal name, etc."
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="keywords" className="block text-sm font-medium text-gray-700 mb-1">
                Keywords (comma separated)
              </label>
              <input
                type="text"
                id="keywords"
                value={newEntry.keywords}
                onChange={(e) => setNewEntry({...newEntry, keywords: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="E.g., technical approach, win strategy, compliance"
              />
            </div>
            
            <div className="flex justify-end space-x-3 pt-4">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark"
              >
                Add Entry
              </button>
            </div>
          </form>
        </div>
      )}
      
      {/* Search and Filter */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="flex-1">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search knowledge base..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>
          <button
            type="submit"
            className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary-dark"
          >
            Search
          </button>
        </form>
        
        <div className="mt-4 border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeCategory === category.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {category.name}
              </button>
            ))}
          </nav>
        </div>
      </div>
      
      {/* Advanced Search Options */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-medium text-gray-900">Advanced Search</h2>
          <button className="text-sm text-primary hover:text-primary-dark">
            Toggle Options
          </button>
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="date-range" className="block text-sm font-medium text-gray-700 mb-1">
              Date Range
            </label>
            <select
              id="date-range"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
            >
              <option value="all">All Time</option>
              <option value="week">Last Week</option>
              <option value="month">Last Month</option>
              <option value="quarter">Last Quarter</option>
              <option value="year">Last Year</option>
            </select>
          </div>
          
          <div>
            <label htmlFor="sort-by" className="block text-sm font-medium text-gray-700 mb-1">
              Sort By
            </label>
            <select
              id="sort-by"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
            >
              <option value="date-desc">Date (Newest First)</option>
              <option value="date-asc">Date (Oldest First)</option>
              <option value="relevance">Relevance</option>
              <option value="title">Title (A-Z)</option>
            </select>
          </div>
          
          <div>
            <label htmlFor="usage-filter" className="block text-sm font-medium text-gray-700 mb-1">
              Usage Filter
            </label>
            <select
              id="usage-filter"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
            >
              <option value="all">All Items</option>
              <option value="high">High Usage</option>
              <option value="medium">Medium Usage</option>
              <option value="low">Low Usage</option>
              <option value="unused">Unused</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Knowledge Items */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-medium text-gray-900">Knowledge Items</h2>
          <div className="text-sm text-gray-500">
            Showing 4 of 245 items
          </div>
        </div>
        
        <ul className="divide-y divide-gray-200">
          <li className="p-6">
            <div className="flex justify-between">
              <div className="flex-1">
                <div className="flex items-center mb-2">
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 mr-2">
                    RFP Insight
                  </span>
                  <span className="text-sm text-gray-500">Added on May 10, 2025</span>
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">Agency Priorities for Cloud-Based Weather Systems</h3>
                <p className="text-gray-600 mb-4">
                  Analysis of recent RFPs shows a strong emphasis on real-time data processing capabilities and integration with existing government systems. Agencies are prioritizing solutions that can handle extreme weather events with minimal latency.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="px-2 py-1 text-xs font-medium rounded-md bg-gray-100 text-gray-800">
                    weather forecasting
                  </span>
                  <span className="px-2 py-1 text-xs font-medium rounded-md bg-gray-100 text-gray-800">
                    cloud computing
                  </span>
                  <span className="px-2 py-1 text-xs font-medium rounded-md bg-gray-100 text-gray-800">
                    real-time processing
                  </span>
                </div>
              </div>
              <div className="ml-4 flex-shrink-0 flex space-x-2">
                <button className="text-gray-400 hover:text-gray-500">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                  </svg>
                </button>
                <button className="text-gray-400 hover:text-red-500">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            </div>
          </li>
          
          <li className="p-6">
            <div className="flex justify-between">
              <div className="flex-1">
                <div className="flex items-center mb-2">
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800 mr-2">
                    Best Practice
                  </span>
                  <span className="text-sm text-gray-500">Added on May 5, 2025</span>
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">Effective Technical Approach Sections</h3>
                <p className="text-gray-600 mb-4">
                  Successful proposals consistently include quantifiable performance metrics and clear differentiation from competitors. Technical approaches should address both immediate requirements and future scalability concerns.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="px-2 py-1 text-xs font-medium rounded-md bg-gray-100 text-gray-800">
                    technical writing
                  </span>
                  <span className="px-2 py-1 text-xs font-medium rounded-md bg-gray-100 text-gray-800">
                    proposal strategy
                  </span>
                  <span className="px-2 py-1 text-xs font-medium rounded-md bg-gray-100 text-gray-800">
                    differentiation
                  </span>
                </div>
              </div>
              <div className="ml-4 flex-shrink-0 flex space-x-2">
                <button className="text-gray-400 hover:text-gray-500">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                  </svg>
                </button>
                <button className="text-gray-400 hover:text-red-500">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            </div>
          </li>
          
          <li className="p-6">
            <div className="flex justify-between">
              <div className="flex-1">
                <div className="flex items-center mb-2">
    
(Content truncated due to size limit. Use line ranges to read in chunks)