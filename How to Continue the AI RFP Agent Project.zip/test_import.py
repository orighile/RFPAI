import sys
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
logging.info(f"TEST_IMPORT: sys.executable: {sys.executable}")
logging.info(f"TEST_IMPORT: sys.path: {str(sys.path)}")
try:
    import pytesseract
    logging.info("TEST_IMPORT: Successfully imported pytesseract")
    print("TEST_IMPORT: Successfully imported pytesseract")
except Exception as e:
    logging.error(f"TEST_IMPORT: Failed to import pytesseract: {e}", exc_info=True)
    print(f"TEST_IMPORT: Failed to import pytesseract: {e}")

