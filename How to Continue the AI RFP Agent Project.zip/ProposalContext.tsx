import React, { createContext, useContext, useState, useEffect } from 'react';
import ApiService from '../services/ApiService';

// Define the Proposal context type
interface ProposalContextType {
  proposals: any[];
  isLoading: boolean;
  error: string | null;
  generateProposal: (data: any) => Promise<any>;
  fetchProposals: (params?: any) => Promise<void>;
  fetchProposalById: (id: string) => Promise<any>;
  updateProposal: (id: string, data: any) => Promise<any>;
  deleteProposal: (id: string) => Promise<void>;
  checkProposalStatus: (id: string) => Promise<any>;
  currentProposal: any | null;
  setCurrentProposal: (proposal: any) => void;
}

// Create the Proposal context
const ProposalContext = createContext<ProposalContextType>({
  proposals: [],
  isLoading: false,
  error: null,
  generateProposal: async () => ({}),
  fetchProposals: async () => {},
  fetchProposalById: async () => ({}),
  updateProposal: async () => ({}),
  deleteProposal: async () => {},
  checkProposalStatus: async () => ({}),
  currentProposal: null,
  setCurrentProposal: () => {},
});

// Proposal provider component
export const ProposalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [proposals, setProposals] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentProposal, setCurrentProposal] = useState<any | null>(null);

  // Fetch all proposals
  const fetchProposals = async (params?: any) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.proposal.getAll(params);
      setProposals(response.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch proposals');
      console.error('Error fetching proposals:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch a proposal by ID
  const fetchProposalById = async (id: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.proposal.getById(id);
      setCurrentProposal(response.data);
      return response.data;
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch proposal');
      console.error('Error fetching proposal:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Generate a new proposal
  const generateProposal = async (data: any) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.proposal.generate(data);
      setProposals((prevProposals) => [...prevProposals, response.data]);
      return response.data;
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to generate proposal');
      console.error('Error generating proposal:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Update a proposal
  const updateProposal = async (id: string, data: any) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await ApiService.proposal.update(id, data);
      setProposals((prevProposals) =>
        prevProposals.map((proposal) => (proposal.id === id ? response.data : proposal))
      );
      if (currentProposal && currentProposal.id === id) {
        setCurrentProposal(response.data);
      }
      return response.data;
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to update proposal');
      console.error('Error updating proposal:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Delete a proposal
  const deleteProposal = async (id: string) => {
    setIsLoading(true);
    setError(null);
    try {
      await ApiService.proposal.delete(id);
      setProposals((prevProposals) => prevProposals.filter((proposal) => proposal.id !== id));
      if (currentProposal && currentProposal.id === id) {
        setCurrentProposal(null);
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to delete proposal');
      console.error('Error deleting proposal:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Check proposal generation status
  const checkProposalStatus = async (id: string) => {
    try {
      const response = await ApiService.proposal.getStatus(id);
      // Update the proposal in the list with status
      setProposals((prevProposals) =>
        prevProposals.map((proposal) => 
          proposal.id === id ? { ...proposal, status: response.data.status } : proposal
        )
      );
      return response.data;
    } catch (err: any) {
      console.error('Error checking proposal status:', err);
      throw err;
    }
  };

  return (
    <ProposalContext.Provider
      value={{
        proposals,
        isLoading,
        error,
        generateProposal,
        fetchProposals,
        fetchProposalById,
        updateProposal,
        deleteProposal,
        checkProposalStatus,
        currentProposal,
        setCurrentProposal,
      }}
    >
      {children}
    </ProposalContext.Provider>
  );
};

// Custom hook to use the Proposal context
export const useProposal = () => useContext(ProposalContext);
