import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import ReviewInterface from '../components/review/ReviewInterface';
import { ProposalProvider } from '../contexts/ProposalContext';

// Mock the API service
jest.mock('../services/ApiService', () => ({
  proposal: {
    getById: jest.fn().mockResolvedValue({
      data: {
        id: 'prop1',
        title: 'Phase 3 RAG Test Proposal for Sky Analytics',
        status: 'in_review',
        content: {
          executiveSummary: 'Test executive summary',
          technicalApproach: 'Test technical approach',
          implementationTimeline: 'Test implementation timeline',
          teamQualifications: 'Test team qualifications'
        }
      }
    }),
  },
  review: {
    getAll: jest.fn().mockResolvedValue({
      data: [
        { id: 1, section: 'Executive Summary', comment: 'The value proposition needs to be more clearly articulated.', severity: 'medium', status: 'open' },
        { id: 2, section: 'Technical Approach', comment: 'Add more quantifiable metrics to demonstrate performance advantages.', severity: 'high', status: 'open' },
        { id: 3, section: 'Implementation Timeline', comment: 'Timeline seems aggressive. Consider adding more buffer for testing phase.', severity: 'medium', status: 'open' },
      ]
    }),
    create: jest.fn()
  }
}));

describe('ReviewInterface Component', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
  });

  test('renders review interface correctly', async () => {
    render(
      <ProposalProvider>
        <ReviewInterface />
      </ProposalProvider>
    );
    
    // Check if important elements are rendered
    expect(screen.getByText(/Proposal Review:/i)).toBeInTheDocument();
    expect(screen.getByText(/Review in Progress/i)).toBeInTheDocument();
    
    // Check if tabs are rendered
    expect(screen.getByText('Proposal Content')).toBeInTheDocument();
    expect(screen.getByText('Feedback Items')).toBeInTheDocument();
    expect(screen.getByText('Compliance Matrix')).toBeInTheDocument();
    expect(screen.getByText('Review Summary')).toBeInTheDocument();
  });

  test('switches between tabs', async () => {
    render(
      <ProposalProvider>
        <ReviewInterface />
      </ProposalProvider>
    );
    
    // Content tab should be active by default
    expect(screen.getByText('Executive Summary')).toBeInTheDocument();
    
    // Switch to Feedback Items tab
    const feedbackTab = screen.getByText('Feedback Items');
    fireEvent.click(feedbackTab);
    
    // Should show feedback items
    expect(screen.getByText('Feedback Items (3 Open)')).toBeInTheDocument();
    
    // Switch to Compliance Matrix tab
    const complianceTab = screen.getByText('Compliance Matrix');
    fireEvent.click(complianceTab);
    
    // Should show compliance matrix
    expect(screen.getByText('Compliance Matrix')).toBeInTheDocument();
    
    // Switch to Review Summary tab
    const summaryTab = screen.getByText('Review Summary');
    fireEvent.click(summaryTab);
    
    // Should show review summary
    expect(screen.getByText('Overall Assessment')).toBeInTheDocument();
  });

  test('adds new feedback', async () => {
    const mockCreate = jest.fn().mockResolvedValue({
      data: {
        id: 4,
        section: 'Team Qualifications',
        comment: 'Need more details on team experience',
        severity: 'medium',
        status: 'open'
      }
    });
    require('../services/ApiService').review.create = mockCreate;
    
    render(
      <ProposalProvider>
        <ReviewInterface />
      </ProposalProvider>
    );
    
    // Fill out the feedback form
    const sectionSelect = screen.getByLabelText(/Section/i);
    const commentTextarea = screen.getByLabelText(/Comment/i);
    const severitySelect = screen.getByLabelText(/Severity/i);
    
    fireEvent.change(sectionSelect, { target: { value: 'Team Qualifications' } });
    fireEvent.change(commentTextarea, { target: { value: 'Need more details on team experience' } });
    fireEvent.change(severitySelect, { target: { value: 'medium' } });
    
    // Submit the form
    const addButton = screen.getByRole('button', { name: /Add Feedback/i });
    fireEvent.click(addButton);
    
    // Verify the feedback was added
    expect(screen.getByText('Team Qualifications')).toBeInTheDocument();
    expect(screen.getByText('Need more details on team experience')).toBeInTheDocument();
  });

  test('changes feedback status', async () => {
    render(
      <ProposalProvider>
        <ReviewInterface />
      </ProposalProvider>
    );
    
    // Switch to Feedback Items tab
    const feedbackTab = screen.getByText('Feedback Items');
    fireEvent.click(feedbackTab);
    
    // Find the status dropdown for the first feedback item
    const statusDropdown = screen.getAllByRole('combobox')[3]; // The first three are for the feedback form
    
    // Change the status to 'addressed'
    fireEvent.change(statusDropdown, { target: { value: 'addressed' } });
    
    // Verify the status was changed
    expect(statusDropdown.value).toBe('addressed');
  });
});
